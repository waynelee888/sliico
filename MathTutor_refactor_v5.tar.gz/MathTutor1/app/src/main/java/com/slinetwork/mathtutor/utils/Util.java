package com.slinetwork.mathtutor.utils;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.view.accessibility.AccessibilityManager;

/**
 * Created by Wayne on 2/2/2016.
 */
public class Util {
    private static Util util = new Util();

    public static Util getInstance() {
        return util;
    }
    private Util() {
    }

    public static AccessibilityManager getAccessibilityManager(Context context) {
        return (AccessibilityManager) context.getSystemService(context.ACCESSIBILITY_SERVICE);
    }

    public static void sayText(TextToSpeech tts, String s) {
        if (tts != null) {
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null);
        }
    }



}
