package com.slinetwork.mathtutor.activities;

import java.io.IOException;
import java.util.Locale;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.AssetFileDescriptor;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.slinetwork.mathtutor.INumberService;
import com.slinetwork.mathtutor.MathTutor;
import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.models.TestRecord;
import com.slinetwork.mathtutor.services.DownloadService;
import com.slinetwork.mathtutor.utils.Const;
import com.slinetwork.mathtutor.utils.Util;

public class MathActivity extends Activity {

	private static final String BASE64_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhaexf45hOxB8Dwlg77E5e2VpaiAbM27yW9TCePcW2VCfQhJlRMh2oi4s/h4enFJXWPdK1iDcthrR42PbmG6FBgY3+W6r2ZdwKVyYT+3qfZdkfEZAZWHPxktcD07Sn7FGvBkDFpvZKls1sQV2hc0h8c6H7AqJHsjn8EDJxfYejyoepKlwB98KIK9ipdrDJhrELBEJp3PDUmeAUjn4K2HhRj4hQTsz/wfJH6tdsZQKGxeA3ZIbe0oeWbdYakfGX66rF/9RykOVhL/inBVayqR6q/vTfFRdxfnJ1T1HVSkXR0aDa/cn7O0p2UQRP5ZIfjP7r/0nvtl0lT4CpB+PuV5LuwIDAQAB";

	static final String TAG = "MathActivity";
	static final String BUZZER_FILENAME = "buzzer.mp3";

	static TextToSpeech tts;


	static final Integer GRADE_ONE_MAX = 5000;
	static final Integer GRADE_ONE_MULT_MAX = 100;
	static final Integer GRADE_ONE_DIV_MAX = 10000;
	static final Integer GRADE_ONE_MIN = 0;
	
	static Integer mMyScore = 0;
	public enum MathOperation {
		NONE, ADDITION, SUBTRACTION, MULTIPLICATION, DIVISION, ALL;
	}
	MathOperation mMathOp;
	Integer mNum1;
	Integer mNum2;
	Integer mMyAnswer;
	Integer mTutorAnswer;
	
	MathTutor mMT;

	Button mButtonDownload;
	Button mButtonAddition;
	Button mButtonSubtraction;
	Button mButtonMultiplication;
	Button mButtonDivision;
	Button mButtonTutorAnswer;
	Button mButtonStartQuestion;
	Button mButtonTestReport;
	Button mButtonTestReportSub;
	Button mButtonTestReportMult;
	Button mButtonTestReportDiv;
	Button mButtonTestReportAll;
    Button mButtonStudent;
	EditText mEditMyScore;
	EditText mEditNum1;
	EditText mEditNum2;
	EditText mEditMyAnswer;
	EditText mEditTutorAnswer;				

	private INumberService mNumService;
	private final ServiceConnection mNumConn = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			mNumService = INumberService.Stub.asInterface(service);
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			mNumService = null;			
		}
		
	};

	private void initTextToSpeech() {
		Intent intent = new Intent(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
		startActivityForResult(intent, Const.TTS_DATA_CHECK);
	}
/*
	private BroadcastReceiver receiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			Bundle bundle = intent.getExtras();
			if (bundle != null) {
				String string = bundle.getString(DownloadService.FILEPATH);
				int resultCode = bundle.getInt(DownloadService.RESULT);
				if (resultCode == RESULT_OK) {
					Toast.makeText(MathActivity.this,
							"Download complete. Download URI: " + string,
							Toast.LENGTH_LONG).show();
				} else {
					Toast.makeText(MathActivity.this, "Download failed",
							Toast.LENGTH_LONG).show();
				}
			}
		}
	};
*/

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_math);

		initTextToSpeech();

		mButtonAddition = (Button) findViewById(R.id.buttonAddition);
		mButtonSubtraction = (Button) findViewById(R.id.buttonSubtraction);
		mButtonMultiplication = (Button) findViewById(R.id.buttonMultiplication);
		mButtonDivision = (Button) findViewById(R.id.buttonDivision);
		mButtonTutorAnswer = (Button) findViewById(R.id.buttonTutorAnswer);
		mButtonStartQuestion = (Button) findViewById(R.id.buttonStartQuestion);
		mButtonTestReport = (Button) findViewById(R.id.buttonTestReport);
		mButtonTestReportSub = (Button) findViewById(R.id.buttonTestReportSub);
		mButtonTestReportMult = (Button) findViewById(R.id.buttonTestReportMult);
		mButtonTestReportDiv = (Button) findViewById(R.id.buttonTestReportDiv);
		mButtonTestReportAll = (Button) findViewById(R.id.buttonTestReportAll);
		mEditMyScore = (EditText)findViewById(R.id.editMyScore);
		mEditNum1 = (EditText)findViewById(R.id.editNum1);
		mEditNum2 = (EditText)findViewById(R.id.editNum2);
		mEditMyAnswer = (EditText)findViewById(R.id.editMyAnswer);
		mEditTutorAnswer = (EditText)findViewById(R.id.editTutorAnswer);

		mButtonDownload = (Button) findViewById(R.id.buttonDownload);
        mButtonStudent = (Button) findViewById(R.id.buttonStudent);

		mMathOp = MathOperation.NONE;
    	mEditMyAnswer.setFocusable(true);
    	
    	Intent iGetNumberService = new Intent("com.slinetwork.mathtutor.NUMBER_SERVICE");
		iGetNumberService.setPackage("com.slinetwork.mathtutor");
    	bindService(iGetNumberService, mNumConn, Context.BIND_AUTO_CREATE);

    	mButtonTestReport.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
            	Intent reportIntent = new Intent(MathActivity.this, ShowReportActivity.class);
            	reportIntent.putExtra("MOP", "+");
            	startActivity(reportIntent);  				
			}
		});
    	mButtonTestReportSub.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
            	Intent reportIntent = new Intent(MathActivity.this, ShowReportActivity.class);
            	reportIntent.putExtra("MOP", "-");
            	startActivity(reportIntent);  				
			}
		});
    	mButtonTestReportMult.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
            	Intent reportIntent = new Intent(MathActivity.this, ShowReportActivity.class);
            	reportIntent.putExtra("MOP", "x");
            	startActivity(reportIntent);  				
			}
		});
    	mButtonTestReportDiv.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
            	Intent reportIntent = new Intent(MathActivity.this, ShowReportActivity.class);
            	reportIntent.putExtra("MOP", "/");
            	startActivity(reportIntent);  				
			}
		});

		mButtonTestReportAll.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent reportIntent = new Intent(MathActivity.this, ShowReportActivity.class);
				reportIntent.putExtra("MOP", "All");
				startActivity(reportIntent);
			}
		});
		mButtonDownload.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent downloadIntent = new Intent(MathActivity.this, DownloadService.class);
				downloadIntent.putExtra(DownloadService.FNAME, "index.html");
				downloadIntent.putExtra(DownloadService.URL_PATH, "http://www.vogella.com/index.html");
				startService(downloadIntent);
			}
		});
        mButtonStudent.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent studentIntent = new Intent(MathActivity.this, StudentActivity.class);
                studentIntent.putExtra("Name", "Wayne");
                startActivity(studentIntent);
            }
        });

		mButtonStartQuestion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	mMyScore = 0;
            	mEditMyScore.setText(mMyScore.toString());
        		mButtonSubtraction.setEnabled(true);
        		mButtonAddition.setEnabled(true);
        		mButtonMultiplication.setEnabled(true);
        		mButtonDivision.setEnabled(true);
        		mButtonTutorAnswer.setEnabled(true);
            	mEditNum1.setText("");
            	mEditNum2.setText("");
            	mEditMyAnswer.setText("");
            	mEditTutorAnswer.setText("");
            	mEditMyAnswer.setFocusable(true);            	
            }
        });
		mButtonAddition.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	
            	mMathOp = MathOperation.ADDITION;
            	if (null == mNumService)
            	{
	            	mNum1 = (int) (Math.random() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
	            	mNum2 = (int) (Math.random() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
            	} else {
	            	try {
						mNum1 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
					} catch (RemoteException e) {
						e.printStackTrace();
					}
	            	try {
						mNum2 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}            		
            	}
            	mEditNum1.setText(mNum1.toString());
            	mEditNum2.setText(mNum2.toString());
            	mEditMyAnswer.setText("");
            	mEditTutorAnswer.setText("");            	
            	mEditMyAnswer.requestFocus();

            }
        });
		mButtonSubtraction.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	mMathOp = MathOperation.SUBTRACTION;
            	if (null == mNumService)
            	{            	
	            	mNum1 = (int) (Math.random() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
	            	mNum2 = (int) (Math.random() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
            	} else {
                	if (null == mNumService)
                	{            	
    	            	mNum1 = (int) (Math.random() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
    	            	mNum2 = (int) (Math.random() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
                	} else {
    	            	try {
    						mNum1 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
    					} catch (RemoteException e) {
    						e.printStackTrace();
    					}
    	            	try {
    						mNum2 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
    					} catch (RemoteException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}            		
                	}
            	}
            	mEditNum1.setText(mNum1.toString());
            	mEditNum2.setText(mNum2.toString());
            	mEditMyAnswer.setText("");
            	mEditTutorAnswer.setText("");            	
            	mEditMyAnswer.requestFocus();
            	
            }
        });
		mButtonMultiplication.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	mMathOp = MathOperation.MULTIPLICATION;
            	if (null == mNumService)
            	{            	
	            	mNum1 = (int) (Math.random() * ( GRADE_ONE_MULT_MAX - GRADE_ONE_MIN ));
	            	mNum2 = (int) (Math.random() * ( GRADE_ONE_MULT_MAX - GRADE_ONE_MIN ));
            	} else {
	            	try {
						mNum1 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_MULT_MAX - GRADE_ONE_MIN ));
					} catch (RemoteException e) {
						e.printStackTrace();
					}
	            	try {
						mNum2 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_MULT_MAX - GRADE_ONE_MIN ));
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}            		            		
            	}
	            	
            	mEditNum1.setText(mNum1.toString());
            	mEditNum2.setText(mNum2.toString());
            	mEditMyAnswer.setText("");
            	mEditTutorAnswer.setText("");            	
            	mEditMyAnswer.requestFocus();            	
            }
        });
		mButtonDivision.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	mMathOp = MathOperation.DIVISION;
            	do 
            	{
                	if (null == mNumService)
                	{            	            		
		            	mNum1 = (int) (Math.random() * ( GRADE_ONE_DIV_MAX - GRADE_ONE_MIN ));
		            	mNum2 = (int) (Math.random() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
                	} else {
    	            	try {
    						mNum1 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_DIV_MAX - GRADE_ONE_MIN ));
    					} catch (RemoteException e) {
    						e.printStackTrace();
    					}
    	            	try {
    						mNum2 = (int) (mNumService.getRandomNumber() * ( GRADE_ONE_MAX - GRADE_ONE_MIN ));
    					} catch (RemoteException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}            		            		
                	}		            	
            	} while (mNum1 < mNum2);
            	if (0==mNum2) 
            		mNum2 = 1;
            	Integer remainderNum = (int)(mNum1 % mNum2);
            	mNum1 = mNum1 - remainderNum;
            	if (0>mNum1) 
            		mNum1 = mNum2;
            	mEditNum1.setText(mNum1.toString());
            	mEditNum2.setText(mNum2.toString());
            	mEditMyAnswer.setText("");
            	mEditTutorAnswer.setText("");            	
            	mEditMyAnswer.requestFocus();            	
            }
        });
		mButtonTutorAnswer.setOnClickListener(new View.OnClickListener() {
			
            public void onClick(View v) {

            	try{            		
            		mMyAnswer = Integer.parseInt(mEditMyAnswer.getText().toString());
            		mNum1 = Integer.parseInt(mEditNum1.getText().toString());
            		mNum2 = Integer.parseInt(mEditNum2.getText().toString());
                	if (mMathOp == MathOperation.ADDITION)
                		calculate("+");
                	else if (mMathOp == MathOperation.SUBTRACTION)
                		calculate("-");
                	else if (mMathOp == MathOperation.MULTIPLICATION)
                		calculate("x");
                	else { // (mMathOp == MathOperation.DIVISION)
                		calculate("/");
                	}    				
            	}catch(NumberFormatException e){
            		if (mMathOp == MathOperation.NONE)
                		Toast.makeText(getApplicationContext(), "Please first select a Math (+ - * /) quiz", Toast.LENGTH_SHORT).show();  
            		else {
						Toast.makeText(getApplicationContext(), "Please enter a number", Toast.LENGTH_SHORT).show();
						Util.getInstance().sayText(tts, "Please enter a number");
					}

					/*
        			try {
						playStopSound(getApplicationContext());
					} catch (IllegalArgumentException e1) {
						Log.e(TAG, e1.toString());
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SecurityException e1) {
						// TODO Auto-generated catch block
						Log.e(TAG, e1.toString());
						e1.printStackTrace();
					} catch (IllegalStateException e1) {
						// TODO Auto-generated catch block
						Log.e(TAG, e1.toString());
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						Log.e(TAG, e1.toString());
						e1.printStackTrace();
					}
					          		*/
           		} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
           			Log.e(TAG, e.toString());
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					Log.e(TAG, e.toString());
					e.printStackTrace();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					Log.e(TAG, e.toString());
					e.printStackTrace();
				}        	            	
            }
        });            	
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		unbindService(mNumConn);
	}
	
	@Override
	public void onBackPressed() {
	    super.onBackPressed();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.math, menu);
		return true;
	}

	public void playSound(Context context) 
			throws IllegalArgumentException, SecurityException, IllegalStateException, IOException {
													
		Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		MediaPlayer mMediaPlayer = new MediaPlayer();
		mMediaPlayer.setDataSource(context, soundUri);
		final AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
		if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
		    mMediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
		    mMediaPlayer.prepare();
		    mMediaPlayer.start();
		}
		
	}

	public void playBellSound(Context context) 
			throws IllegalArgumentException, SecurityException, IllegalStateException, IOException {		
		
		MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.bell); 
		mediaPlayer.start();
	    		
	}	
	
	public void playBuzzerSound(Context context, String filename) 
			throws IllegalArgumentException, SecurityException, IllegalStateException, IOException {		
		
	    AssetFileDescriptor afd = getAssets().openFd(filename);
	    MediaPlayer player = new MediaPlayer();
	    player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
	    player.prepare();
	    player.start();

	}

	public void playStopSound(Context context) 
			throws IllegalArgumentException, SecurityException, IllegalStateException, IOException {		
		
		MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.stop); 
		mediaPlayer.start();
	    		
	}	
	
	private void compareResults(Integer tutorAnswer) {
		mTutorAnswer = tutorAnswer;
		if (mMyAnswer.equals(mTutorAnswer))
		{
			mMyScore++;
    		mEditMyScore.setText(mMyScore.toString());
    		mEditTutorAnswer.setText(mTutorAnswer.toString());        		        			
			Toast.makeText(getApplicationContext(), "You got it!!", Toast.LENGTH_SHORT).show();          	
			mButtonAddition.requestFocus();
			
			// playSound(getApplicationContext());
			try {
				playBellSound(getApplicationContext());
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			Toast.makeText(getApplicationContext(), "Please try again", Toast.LENGTH_SHORT).show();
			Util.getInstance().sayText(tts, "Incorrect answer, please try again.");
			/*
			try {
				playBuzzerSound(getApplicationContext(), BUZZER_FILENAME);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			*/
		}
	}
	
	private void recordResults() {
		mMT = (MathTutor)(MathActivity.this.getApplication());
		if (mMT.getRSStatus()) {
            String op = "";
            switch (mMathOp) {
                case MULTIPLICATION:
                    op = "x";
                    break;
                case ADDITION:
                    op = "+";
                    break;
                case SUBTRACTION:
                    op= "-";
                    break;
                default:
                    op = "/";
                    break;
            }
			TestRecord trec = new TestRecord(mMathOp, mNum1, op, mNum2, mMyAnswer, mTutorAnswer);
			mMT.getRS().logTest(trec);
		}
		
	}
	
	private void calculate(String mop) {

		mMT = (MathTutor)(MathActivity.this.getApplication());
		mMT.setMathActivity(MathActivity.this);
		
		if (mMT.getMAStatus()) {
    		Message msg = Message.obtain();
    		msg.what = MathTutor.MSG_MATH_OP;
    		Bundle rBundle = new Bundle();
    		// rBundle.putString("MOP", "/");
    		rBundle.putString("MOP", mop);
    		rBundle.putString("NUM1", mNum1.toString());
    		rBundle.putString("NUM2", mNum2.toString());
    		msg.setData(rBundle);
			try {
				mMT.getMA().send(msg);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}                		
	}
	
	public void receiveResults(Integer tutorAnswer) {
		compareResults(tutorAnswer);
		recordResults();
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if( requestCode == Const.TTS_DATA_CHECK ) {
			if( resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS ) {
				tts = new TextToSpeech(this.getApplicationContext(), new TextToSpeech.OnInitListener() {
					@Override
					public void onInit(int status) {
						if( status == TextToSpeech.SUCCESS ) {
							String lang =Locale.getDefault().getLanguage();
							String lang2 = Locale.CANADA.toString();
							String lang3 = Locale.ENGLISH.toString();
							if (lang.equalsIgnoreCase(lang2) || lang.equalsIgnoreCase(lang3)) {
								if (tts.isLanguageAvailable(Locale.CANADA) == TextToSpeech.LANG_COUNTRY_AVAILABLE) {
									tts.setLanguage(Locale.CANADA);
								} else {
									tts.setLanguage(Locale.ENGLISH);
								}
							}
						}
					}
				});
			}
		}

	}

	@Override
	protected void onResume() {
		super.onResume();
//		registerReceiver(receiver, new IntentFilter(
//				DownloadService.NOTIFICATION));
	}

	@Override
	protected void onPause() {
		super.onPause();
//		unregisterReceiver(receiver);
	}
}


