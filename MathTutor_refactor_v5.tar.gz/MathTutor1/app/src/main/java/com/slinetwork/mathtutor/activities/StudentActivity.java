package com.slinetwork.mathtutor.activities;

/**
 * Created by wayne on 26/07/17.
 */


import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;

import android.content.ContentValues;
import android.content.CursorLoader;

import android.database.Cursor;

import android.util.Log;
import android.view.Menu;
import android.view.View;

import android.widget.EditText;
import android.widget.Toast;

import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.providers.StudentsProvider;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class StudentActivity extends Activity {
    ArrayList<String> namelists;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.student);
            init();
        }

    @Override
    protected void onResume() {
        super.onResume();
        readNames("name.txt",0,0);
        showNames();
    }
    private void init(){
        namelists = new ArrayList<>(0);
    }

    private void readNames(String filename) {
        try {
            // InputStream is = openFileInput(filename);
            InputStream is = this.getAssets().open(filename);
            InputStreamReader bis = new InputStreamReader(is);
            BufferedReader reader = new BufferedReader(bis);
            String line;
            while ((line = reader.readLine()) != null) {
                namelists.add(line);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void readFile(String filename) {
        File file = new File(filename);
        try {
            InputStream is = new FileInputStream(file);
            InputStreamReader bis = new InputStreamReader(is);
            BufferedReader reader = new BufferedReader(bis);
            String line;
            while ((line = reader.readLine()) != null) {
                Log.d("TEMP", line);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void readNames(String filename, int a) {
        String outputfile = getFilesDir() + File.separator + "temp.txt";
        copyAssetFileToBufferFile(filename, outputfile);
        File f = new File(outputfile);
        try {
            InputStream is = new FileInputStream(f);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));

            String line;
            try {
                while ((line = bufferedReader.readLine()) != null) {
                    namelists.add(line);
                }
            } catch( EOFException fe) {
                fe.printStackTrace();
            } finally {
                is.close();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void readNames(String filename, int a, int b) {
        String outputfile = getExternalFilesDir(null)+ File.separator + "tempobj.txt";
        copyAssetFileToBufferObjectFile(filename, outputfile);
        File f = new File(outputfile);
        try {
            InputStream is = new FileInputStream(f);
            ObjectInputStream ois = new ObjectInputStream(is);
            String line;
            Object o;
            try {
                while ((o = ois.readObject()) != null) {
                    line = (String)o;
                    namelists.add(line);
                }
                ois.close();
            } catch( EOFException fe) {
                fe.printStackTrace();
            }

            catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    private void copyAssetFileToBufferFile(String filename, String outputfile) {
        try {
            InputStream is = this.getAssets().open(filename);
            BufferedInputStream bis = new BufferedInputStream(is);
            DataInputStream dis = new DataInputStream(bis);
            byte [] data = new byte[1024];
            int len;
            int offset=0;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            try {
                while ((len = dis.read(data, 0, 1024)) != -1) {
                    bos.write(data, offset, len);
                    offset += len;
                }
                OutputStream os = new FileOutputStream(outputfile);
                bos.writeTo(os);
                bos.flush();

                readFile(outputfile);
            } catch (IOException e1) {
                e1.printStackTrace();
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void copyAssetFileToBufferObjectFile(String filename, String outputfile) {
        try {
            InputStream is = this.getAssets().open(filename);
            BufferedInputStream bis = new BufferedInputStream(is);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));
            ObjectOutputStream dos = new ObjectOutputStream(new FileOutputStream(new File(outputfile)));
            String line;
            try {
                while ((line = bufferedReader.readLine()) != null) {

                    dos.writeObject(line);
                }
                dos.close();

            } catch (IOException e1) {
                e1.printStackTrace();
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void showNames() {
        Iterator<String> iterator = namelists.iterator();
        while (iterator.hasNext()) {
            Log.d("Name", iterator.next());
        }

        for (String s : namelists) {
            Log.d("Name2", s);
        }


        for (int i=0; i<namelists.size(); ++i) {
            Log.d("Name3", namelists.get(i));
        }
    }

    public void onClickAddName(View view) {
            // Add a new student record
            ContentValues values = new ContentValues();
            values.put(StudentsProvider.NAME,
                    ((EditText)findViewById(R.id.editText2)).getText().toString());

            values.put(StudentsProvider.GRADE,
                    ((EditText)findViewById(R.id.editText3)).getText().toString());

            Uri uri = getContentResolver().insert(
                    StudentsProvider.CONTENT_URI, values);

            Toast.makeText(getBaseContext(),
                    uri.toString(), Toast.LENGTH_LONG).show();
        }
        public void onClickRetrieveStudents(View view) {
            // Retrieve student records
            String URL = "content://com.slinetwork.mathtutor.providers.StudentsProvider";

            Uri students = StudentsProvider.CONTENT_URI; // Uri.parse(URL);
            Cursor c = managedQuery(students, null, null, null, "name");

            if (c.moveToFirst()) {
                do{
                    Toast.makeText(this,
                            c.getString(c.getColumnIndex(StudentsProvider._ID)) +
                                    ", " +  c.getString(c.getColumnIndex( StudentsProvider.NAME)) +
                                    ", " + c.getString(c.getColumnIndex( StudentsProvider.GRADE)),
                            Toast.LENGTH_SHORT).show();
                } while (c.moveToNext());
            }
        }
    }

