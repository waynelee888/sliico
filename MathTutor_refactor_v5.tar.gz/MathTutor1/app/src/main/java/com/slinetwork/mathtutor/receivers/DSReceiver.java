package com.slinetwork.mathtutor.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.slinetwork.mathtutor.services.DownloadService;

import static android.app.Activity.RESULT_OK;

/**
 * Created by wayne on 25/07/17.
 */

public class DSReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            String string = bundle.getString(DownloadService.FILEPATH);
            int resultCode = bundle.getInt(DownloadService.RESULT);
            if (resultCode == RESULT_OK) {
                Toast.makeText(context,
                        "Download complete. Download URI: " + string,
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(context, "Download failed",
                        Toast.LENGTH_LONG).show();
            }
        }

    }
}
