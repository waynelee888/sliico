package com.slinetwork.mathtutor.models;

/**
 * Created by wayne on 25/07/17.
 */

public class StudentInfo {
    // student id
    // student name
}
