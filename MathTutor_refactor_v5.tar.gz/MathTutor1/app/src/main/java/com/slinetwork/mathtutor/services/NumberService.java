package com.slinetwork.mathtutor.services;

import java.util.Random;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import com.slinetwork.mathtutor.INumberService;

public class NumberService extends Service {

	private final Random mGenerator = new Random();
	
    @Override
    public void onCreate() {
        super.onCreate();
    }

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		super.onStartCommand(intent, flags, startId);
		return Service.START_STICKY;
	}
	@Override
	public IBinder onBind(Intent arg0) {
		return (IBinder) mNumSrv;
	}

	private final INumberService mNumSrv = new INumberService.Stub() {
		
		@Override
		public double getRandomNumber() throws RemoteException {
			return Math.random();
		}

		@Override
		public int getRandomNumberRange(int max) throws RemoteException {
			return mGenerator.nextInt(max);
		}
	};
}
