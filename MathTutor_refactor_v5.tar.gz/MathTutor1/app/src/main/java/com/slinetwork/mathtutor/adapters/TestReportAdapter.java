package com.slinetwork.mathtutor.adapters;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.slinetwork.mathtutor.R;

public class TestReportAdapter extends CursorAdapter {

	String mMathOp;
	private int count=0;
	public TestReportAdapter(Context context, Cursor c, boolean autoRequery) {
		super(context, c, autoRequery);
	}
	
	public TestReportAdapter(Context context, Cursor c, boolean autoRequery, String mathOp) {
		super(context, c, autoRequery);
		mMathOp = mathOp;
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		TextView textItemId = (TextView) view.findViewById(R.id.textItemId);
		textItemId.setText(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(1))));
		// textItemId.setText(String.valueOf(++count));

        TextView textItemMathOp = (TextView) view.findViewById(R.id.textItemMathOp);
        textItemMathOp.setText(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(3))));

        TextView textItemNum1 = (TextView) view.findViewById(R.id.textItemNum1);
        textItemNum1.setText(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(2))));

        TextView textItemMathNum2 = (TextView) view.findViewById(R.id.textItemMathNum2);
        textItemMathNum2.setText(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(4))));

        TextView textItemMathTestResult = (TextView) view.findViewById(R.id.textItemMathTestResult);
        textItemMathTestResult.setText(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(5))));

        TextView textItemMathTutorResult = (TextView) view.findViewById(R.id.textItemMathTutorResult);
        textItemMathTutorResult.setText(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(6))));
        
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
		LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View riView = inflater.inflate(R.layout.report_item, parent, false); 		
		return riView;
	}

}
