package com.slinetwork.mathtutor;

import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

import com.slinetwork.mathtutor.activities.MathActivity;
import com.slinetwork.mathtutor.services.MathService;
import com.slinetwork.mathtutor.services.RecordAccessService;

public class MathTutor extends Application {

	static final String TAG = "MathTutor";

    private static MathTutor instance;

	MathActivity mMath;
	
    public static final int MSG_REGISTER_CLIENT = 1;
    public static final int MSG_UNREGISTER_CLIENT = 2;
    public static final int MSG_MATH_OP = 3;
	
	RecordAccessService mRecService;
	boolean mRSBound;
	
	Messenger mMathOpMessenger;
	boolean mMABound = false;
	
	Integer mTutorAnswer;
	
	Messenger mMathAnswerMessenger;

	public MathTutor() {
		HandlerThread ht = new HandlerThread("MathHandlerThread");
		ht.start();
		mMathAnswerMessenger = new Messenger(new MathAnswerHandler(ht));

	}
	
	public Handler mResultHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
            case MathTutor.MSG_MATH_OP:
            	mMath.receiveResults(msg.arg1);
            	break;
            default:
                super.handleMessage(msg);	
			}
		}
	};
	
	class MathAnswerHandler extends Handler {
		
		public MathAnswerHandler(HandlerThread ht) {
			super(ht.getLooper());
		}
		public void handleMessage(Message msg) {
			Log.d(TAG, "handleMessage");
			
			switch (msg.what) {
            case MathTutor.MSG_MATH_OP:
            	Message res = Message.obtain();
            	res.what = msg.what;
            	res.arg1 = msg.arg1;
            	mResultHandler.sendMessage(res);
            	break;
            default:
                super.handleMessage(msg);
            	
			}
		}
		
	}
	// Messenger mMathAnswerMessenger = new Messenger(new MathAnswerHandler());
	
	class ReportServiceConnection implements ServiceConnection {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			RecordAccessService.RSBinder binder = (RecordAccessService.RSBinder)service;
			mRecService = binder.getService();
			mRSBound = true;
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			mRSBound = false;
		}
		
	}
	ReportServiceConnection mRSConn = new ReportServiceConnection();
	
	class MathServiceConnection implements ServiceConnection {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			mMathOpMessenger = new Messenger(service);
			mMABound = true;
			
    		Message msg = Message.obtain();
    		msg.what = MathTutor.MSG_REGISTER_CLIENT;
    		msg.replyTo = mMathAnswerMessenger;
    		try {
				mMathOpMessenger.send(msg);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
    		
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			mMABound = false;
			Message msg = Message.obtain();
			msg.what = MathTutor.MSG_UNREGISTER_CLIENT;
			msg.replyTo = mMathOpMessenger;
			try {
				mMathOpMessenger.send(msg);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	MathServiceConnection mMAConn = new MathServiceConnection();
	
	
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// TODO Auto-generated method stub
		super.onConfigurationChanged(newConfig);
	}

	@Override
	public void onCreate() {
		super.onCreate();
		
		mRSBound = false;
		Intent rsIntent = new Intent(this, RecordAccessService.class);		
		bindService(rsIntent, mRSConn, Context.BIND_AUTO_CREATE);
		
		mMABound = false;
		Intent maIntent = new Intent("com.slinetwork.mathtutor.MATH_SERVICE");
        maIntent.setPackage("com.slinetwork.mathtutor");
		Bundle b = new Bundle();
		b.putString("MT", "MS");
		maIntent.putExtras(b);
		bindService(maIntent, mMAConn, Context.BIND_AUTO_CREATE);

            instance = this;
	}

	@Override
	public void onLowMemory() {
		// TODO Auto-generated method stub
		super.onLowMemory();
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
	    if(mMABound){
			unbindService(mMAConn);
			mMAConn = null;
			mMABound = false;
			stopService(new Intent(getApplicationContext(), MathService.class));
	    }
	    if(mRSBound){					
			unbindService(mRSConn);
			mRSConn = null;
			mRSBound = false;
			stopService(new Intent(getApplicationContext(), RecordAccessService.class));
	    }
	}
	
	public void setMathActivity(MathActivity ma) {
		mMath = ma;
	}
	
	public boolean getRSStatus() {
		return mRSBound;
	}
	
	public RecordAccessService getRS() {
		return mRecService;
	}
	
	public boolean getMAStatus() {
		return mMABound;
	}
	public Messenger getMA() {
		return mMathOpMessenger;
	}
	
	public Cursor getAddsTableCursor() {
		Cursor addsCursor = mRecService.readAddsTable();
		return addsCursor;
	}
	public Cursor getSubsTableCursor() {
		Cursor addsCursor = mRecService.readSubsTable();
		return addsCursor;
	}
	public Cursor getMultsTableCursor() {
		Cursor addsCursor = mRecService.readMultsTable();
		return addsCursor;
	}
	public Cursor getDivsTableCursor() {
		Cursor addsCursor = mRecService.readDivsTable();
		return addsCursor;
	}
    public Cursor getAllTableCursor() {
        Cursor addsCursor = mRecService.readAllTable();
        return addsCursor;
    }

    public static Context getContext() {return instance.getApplicationContext();}
}
