package com.slinetwork.mathtutor.models;

/**
 * Created by wayne on 25/07/17.
 */

public class Session {
    // record the time of each login session
    // use this session id as in record
}
