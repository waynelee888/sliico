package com.slinetwork.mathtutor.utils;

/**
 * Created by Wayne on 2/2/2016.
 */
public class Const {
    public static final int TTS_DATA_CHECK = 0001;
    public static final String TTS_MSG_KEY = "TEXT";
}
