package com.slinetwork.mathtutor.networks;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpRequest {

    private HttpMethods httpMethods;
    private HttpParams httpParams;
    private HttpHeader httpHeader;


    public void setHttpHeader(HttpHeader httpHeader) {
        this.httpHeader = httpHeader;
    }
    public HttpHeader getHttpHeader() {
        return httpHeader;
    }

    public void setHttpMethods(HttpMethods httpMethods) {
        this.httpMethods = httpMethods;
    }
    public HttpMethods getHttpMethods() {
        return httpMethods;
    }

    public void setHttpParams(HttpParams httpParams) {
        this.httpParams = httpParams;
    }
    public HttpParams getHttpParams() {
        return httpParams;
    }
}
