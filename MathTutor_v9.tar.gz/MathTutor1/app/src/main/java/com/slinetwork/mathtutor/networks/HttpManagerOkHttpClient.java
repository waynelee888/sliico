package com.slinetwork.mathtutor.networks;

import android.content.Context;
import android.os.Build;
import android.os.Environment;

import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.HttpUrl;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.internal.Util;

import org.apache.http.NameValuePair;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.List;
import java.util.jar.Attributes;

import okio.BufferedSink;
import okio.Okio;
import okio.Source;

/**
 * Created by wayne on 13/08/17.
 */

public class HttpManagerOkHttpClient extends HttpManagerBase {
    OkHttpClient httpClient;
    Context context;

    String assetFile;

    MediaType mediaType;


    public HttpManagerOkHttpClient() {
        httpClient = new OkHttpClient();
    }

    public HttpManagerOkHttpClient(Context context) {

        this.context = context;
        httpClient = new OkHttpClient();
    }

    public void setAssetFileName(String fileName) {
        assetFile = fileName;
    }

    public void setMediaType(MediaType mediaType) {
        this.mediaType = mediaType;
    }


    @Override
    public HttpResponse httpExecute() {
        HttpResponse httpResponse = new HttpResponse();
        if (httpRequest.getHttpMethods() instanceof HttpGetMethod) {
            HttpUrl.Builder urlBuilder = HttpUrl.parse(httpRequest.getHttpParams().url.toString()).newBuilder();

            List<NameValuePair> pairList = httpRequest.getHttpParams().getParams();

            for (NameValuePair aPair : pairList) {
                urlBuilder.addQueryParameter(aPair.getName(), aPair.getValue());
            }
            String url = urlBuilder.build().toString();

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            try {
                Response response = httpClient.newCall(request).execute();

                InputStream is = response.body().byteStream();


                File file;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    String outputfile = context.getFilesDir() + File.separator + "httptest.html";
                    file = new File(outputfile);
                } else {
                    file = new File(Environment.getExternalStorageDirectory(), File.separator + "httptest.html");
                }
                if (file.exists()) {
                    file.delete();
                }

                BufferedInputStream input = new BufferedInputStream(is);
                OutputStream output = new FileOutputStream(file);

                byte[] data = new byte[1024];
                int count;

                long total = 0;

                while ((count = input.read(data)) != -1) {
                    total += count;
                    output.write(data, 0, count);
                }

                output.flush();
                output.close();
                input.close();

                HttpError httpError = new HttpError();
                httpError.errorType = HttpError.ErrorType.ERROR_TYPE_NONE;
                httpResponse.setHttpError(httpError);
                responseListener.onHttpSuccess(httpResponse);
            } catch (IOException e) {
                e.printStackTrace();
            }

        } else if (httpRequest.getHttpMethods() instanceof HttpPostMethod) {
            RequestBody requestBody;
            FormEncodingBuilder formBuilder = new FormEncodingBuilder();
            List<NameValuePair> pairList = httpRequest.getHttpParams().getParams();

            for (NameValuePair aPair : pairList) {
                formBuilder.add(aPair.getName(), aPair.getValue());
            }

            RequestBody formBody = formBuilder.build();

            Request request = new Request.Builder()
                    .url(httpRequest.getHttpParams().url)
                    .post(formBody)
                    .build();

            BufferedInputStream input = null;
            OutputStream output = null;
            try {
                Response response = httpClient.newCall(request).execute();

                InputStream is = response.body().byteStream();

                File file;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {


                    String outputfile = context.getFilesDir() + File.separator + "httptest.html";
                    file = new File(outputfile);

                } else {

                    file = new File(Environment.getExternalStorageDirectory(), File.separator + "httptest.html");
                }
                if (file.exists()) {
                    file.delete();
                }

                input = new BufferedInputStream(is);
                output = new FileOutputStream(file);

                byte[] data = new byte[1024];
                int count;

                long total = 0;

                while ((count = input.read(data)) != -1) {
                    total += count;
                    output.write(data, 0, count);
                }

                output.flush();


                HttpError httpError = new HttpError();
                httpError.errorType = HttpError.ErrorType.ERROR_TYPE_NONE;
                httpResponse.setHttpError(httpError);
                responseListener.onHttpSuccess(httpResponse);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    output.close();
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return httpResponse;

    }

    private static class RequestBodyUtil {

        public static RequestBody create(final MediaType mediaType, final InputStream inputStream) {
            return new RequestBody() {
                @Override
                public MediaType contentType() {
                    return mediaType;
                }

                @Override
                public long contentLength() {
                    try {
                        return inputStream.available();
                    } catch (IOException e) {
                        return 0;
                    }
                }

                @Override
                public void writeTo(BufferedSink sink) throws IOException {
                    Source source = null;
                    try {
                        source = Okio.source(inputStream);
                        sink.writeAll(source);
                    } finally {
                        Util.closeQuietly(source);
                    }
                }
            };
        }
    }
}
