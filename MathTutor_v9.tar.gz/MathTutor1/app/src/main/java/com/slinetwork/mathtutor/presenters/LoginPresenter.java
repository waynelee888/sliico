package com.slinetwork.mathtutor.presenters;

import com.slinetwork.mathtutor.activities.LoginActivity;
import com.slinetwork.mathtutor.models.LoginCredential;

import static com.slinetwork.mathtutor.activities.LoginActivity.LoginStatus.FAIL_MANY_ATTEMPT;

/**
 * Created by wayne on 11/08/17.
 */

public class LoginPresenter {
    LoginValidater loginValidater;
    public LoginPresenter(LoginValidater loginValidater) {
        this.loginValidater = loginValidater;
    }
    public void loginCheck(LoginCredential loginCredential) {

        if (true) {
            loginValidater.loginStatus(true);
        } else {
            loginValidater.showStatus(FAIL_MANY_ATTEMPT);
        }
    }
    public interface LoginValidater {
        public void showStatus(String status);
        public void loginStatus(Boolean staus);
    }
}
