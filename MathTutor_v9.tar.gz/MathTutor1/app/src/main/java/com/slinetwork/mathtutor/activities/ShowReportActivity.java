package com.slinetwork.mathtutor.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;

import com.slinetwork.mathtutor.MathTutor;
import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.adapters.TestReportAdapter;

public class ShowReportActivity extends Activity {

	MathTutor mMT;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_report);
		
		Intent srIntent = getIntent();
		Bundle srBundle = srIntent.getExtras();
		String mop = (String)srBundle.get("MOP");

		ListView listViewReport = (ListView) findViewById(R.id.listViewReport);
		mMT = (MathTutor)(ShowReportActivity.this.getApplication());
		
		Cursor cursor;
		if (mop.equals("+")) {
			cursor = mMT.getAddsTableCursor();
		} else if (mop.equals("-")) {
			cursor = mMT.getSubsTableCursor();			
		} else if (mop.equals("x")) {
			cursor = mMT.getMultsTableCursor();
		} else if (mop.equals("/")) {
			cursor = mMT.getDivsTableCursor();
		} else if (mop.equals("All")) {
			cursor = mMT.getAllTableCursor();
		} else {
			cursor = null;
		}
		listViewReport.setAdapter(new TestReportAdapter(this, cursor , false, mop));
	}
	
}
