package com.slinetwork.mathtutor.models;

/**
 * Created by wayne on 11/08/17.
 */

public class LoginCredential {
    public String name;
    public String pwd;
}
