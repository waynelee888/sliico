package com.slinetwork.mathtutor.utils;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;

/**
 * Created by wayne on 06/08/17.
 */

public class RunProcess {
    private static RunProcess runProcess = null;
    private RunProcess() {

    }
    public static RunProcess getInstance() {
        if (runProcess == null) {
            runProcess = new RunProcess();
        }
        return runProcess;
    }

    public void start(Context context) {
        try {

            InputStream rsis = context.getAssets().open("run_root_shell");
            //String path = getFilesDir().getAbsolutePath();
            String path = "/data/local/tmp";
            File rso = new File(path, "run_root_shell_exe");
            if (rso.exists()) {
                rso.delete();
            }

            File f = new File(path, "run_root_shell_buffer");

            FileOutputStream fos = new FileOutputStream(f);
            int b;
            while ((b = rsis.read()) != -1) {
                fos.write(b);
            }
            fos.close();
            rsis.close();


            FileInputStream rsfis = new FileInputStream(f);
            FileChannel rsfcis = rsfis.getChannel();

            FileOutputStream rsfos = new FileOutputStream(rso);
            FileChannel rsfcos = rsfos.getChannel();

            rsfcis.transferTo(0, f.length(), rsfcos);

            rsfcos.close();
            rsfcis.close();

            f.setExecutable(true);
            Process process = Runtime.getRuntime().exec(f.getAbsolutePath());


        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
