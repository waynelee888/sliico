package com.slinetwork.mathtutor.services;

import java.util.ArrayList;
import java.util.Iterator;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

import com.slinetwork.mathtutor.MathTutor;

public class MathService extends Service {

	static final String TAG = "MathService";

    static final int MAX_CLIENTS = 1;

	private Messenger mMessenger = new Messenger(new MathOpH());
	private ArrayList<Messenger> mClients= new ArrayList<>();

	@Override
	public IBinder onBind(Intent intent) {
		Log.d(TAG, "onBind");

		Bundle b = intent.getExtras();
		String v = b.getString("MT");
		Log.d("MT", v);

		return mMessenger.getBinder();
	}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return Service.START_STICKY;
    }

    void sendResult(String op, final Integer res) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Iterator<Messenger> messengerIterator = mClients.iterator();
                while (messengerIterator.hasNext()) {
                    Message m = new Message();
                    m.what = MathTutor.MSG_MATH_OP;
                    m.arg1 = res.intValue();
                    try {
                        messengerIterator.next().send(m);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }

            }
        }).start();

    }

	class MathOpH extends Handler {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case MathTutor.MSG_REGISTER_CLIENT:
                    mClients.add(msg.replyTo);
                    break;
                case MathTutor.MSG_UNREGISTER_CLIENT:
                    mClients.remove(msg.replyTo);
                    break;
                case MathTutor.MSG_MATH_OP:
                    Integer res = 0;
                    Bundle b = (Bundle) msg.getData();
                    String op = b.getString("MOP");
                    Integer num1 = Integer.parseInt(b.getString("NUM1"));
                    Integer num2 = Integer.parseInt(b.getString("NUM2"));
                    switch (op) {
                        case "+":
                            res = num1+num2;
                            break;
                        case "-":
                            res = num1-num2;
                            break;
                        case "/":
                            res = (Integer) (num1/num2);
                            break;
                        case "x":
                            res = (Integer) (num1*num2);
                            break;
                        default: break;
                    }
                    sendResult(op, res);
                    break;

                default:
                    break;
            }
        }


    }
	
	class MathOpHandler extends Handler {
		
		@Override
		public void handleMessage(Message msg) {
			String mathOp;
			Bundle recordBundle;
			Integer num1;
			Integer num2;
			//Integer tutorResult=0;
			Messenger client;
			int tutorResult = 0;
			
			switch (msg.what) {
            case MathTutor.MSG_REGISTER_CLIENT:
                mClients.add(msg.replyTo);
                break;
            case MathTutor.MSG_UNREGISTER_CLIENT:
                mClients.remove(msg.replyTo);
                break;
            case MathTutor.MSG_MATH_OP:
    			Log.d(TAG, "handleMessage");

            	recordBundle = msg.getData();
            	mathOp = (String)recordBundle.get("MOP");
            	String n1 = (String)recordBundle.get("NUM1");
            	String n2 = (String)recordBundle.get("NUM2");
            	num1 = Integer.parseInt((String)recordBundle.get("NUM1"));
            	num2 = Integer.parseInt((String)recordBundle.get("NUM2"));
            	
        		if (mathOp.equals("+")) {
                	tutorResult = (int)(num1 + num2);
        		} else if (mathOp.equals("-")) {
                	tutorResult = (int)(num1 - num2);
        		} else if (mathOp.equals("x")) {
                	tutorResult = (int)(num1 * num2);
        		} else {
                	tutorResult = (int)(num1 / num2);
        		}	
				final Message reMsg = Message.obtain();
				reMsg.arg1 = tutorResult;
				reMsg.what = MathTutor.MSG_MATH_OP;

				new Thread(new Runnable() {
					@Override
					public void run() {
						Iterator<Messenger> mesnIt = mClients.iterator();
						while(mesnIt.hasNext()) {
							Messenger m = mesnIt.next();
							try {
								m.send(reMsg);
							} catch (RemoteException e) {
								e.printStackTrace();
							}
						}
					}
				}).start();

                break;
            default:
                super.handleMessage(msg);
            }
					
		}
		
	}

}
