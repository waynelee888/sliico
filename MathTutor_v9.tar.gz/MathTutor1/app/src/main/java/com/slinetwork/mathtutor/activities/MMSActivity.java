package com.slinetwork.mathtutor.activities;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.slinetwork.mathtutor.utils.DatabaseUtil;

/**
 * Created by wayne on 05/08/17.
 */

public class MMSActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DatabaseUtil.copyDatabaseToExtStg(getApplicationContext());
    }
}