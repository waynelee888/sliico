package com.slinetwork.mathtutor.networks;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpManagerLoopjAsync extends HttpManagerBase {
    @Override
    public HttpResponse httpExecute() {
        return null;
    }
}
