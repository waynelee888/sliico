package com.slinetwork.mathtutor.models;

/**
 * Created by wayne on 25/07/17.
 */

public class Account {
    // account number
    // student id
}
