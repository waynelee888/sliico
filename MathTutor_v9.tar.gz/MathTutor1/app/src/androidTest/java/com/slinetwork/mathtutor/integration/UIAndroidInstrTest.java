package com.slinetwork.mathtutor.integration;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.support.test.InstrumentationRegistry;
import android.support.test.espresso.core.deps.guava.base.Strings;
import android.support.test.filters.SdkSuppress;
import android.support.test.runner.AndroidJUnit4;
import android.support.test.uiautomator.By;
import android.support.test.uiautomator.BySelector;
import android.support.test.uiautomator.EventCondition;
import android.support.test.uiautomator.UiDevice;
import android.support.test.uiautomator.UiObject;
import android.support.test.uiautomator.UiObject2;
import android.support.test.uiautomator.UiObjectNotFoundException;
import android.support.test.uiautomator.UiSelector;
import android.util.Log;

import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.internals.managers.ThreadManager;

import org.junit.Before;
import org.junit.runner.RunWith;

import java.io.File;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

/**
 * Created by wayne on 10/08/17.
 */


@RunWith(AndroidJUnit4.class)
@SdkSuppress(minSdkVersion = 18)
public class UIAndroidInstrTest {
    private UiDevice mDevice;
    @Before
    public void before() {
        // Initialize UiDevice instance
        mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        assertThat(mDevice, notNullValue());

        // Start from the home screen
        mDevice.pressHome();


    }
    @org.junit.Test
    public void test() throws InterruptedException {
        openApp("com.slinetwork.mathtutor");


        UiObject2 protectObject = waitForObject(By.res("com.slinetwork.mathtutor:id/login"));
        Boolean b = protectObject.isClickable();
        protectObject.click();

        waitForObject(By.res("com.slinetwork.mathtutor:id/editMyAnswer"));


        takeScreenshot("screenshot-1.png");

        protectObject = waitForObject(By.text("Addition"));
        protectObject.click();


        takeScreenshot("screenshot-2.png");

        UiObject editText = new UiObject(new UiSelector().resourceId("com.slinetwork.mathtutor:id/editMyAnswer"));
        if (editText.exists()) {
            try {
                editText.setText("1236");
            } catch (UiObjectNotFoundException e) {
                e.printStackTrace();
            }
        }
        takeScreenshot("screenshot-3.png");

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            mDevice.pressBack();
        }
        UiObject2 tuturObject = waitForObject(By.text("Tutor Answer"));
        tuturObject.click();
        takeScreenshot("screenshot-4.png");

        UiObject num1 = new UiObject(new UiSelector().resourceId("com.slinetwork.mathtutor:id/editNum1"));
        UiObject num2 = new UiObject(new UiSelector().resourceId("com.slinetwork.mathtutor:id/editNum2"));


        UiObject2 testObject2 = waitForObject(By.res("com.slinetwork.mathtutor:id/editNum1"));
        String num1S = testObject2.getText();
        UiObject2 editTextObj2 = mDevice.findObject(By.res("com.slinetwork.mathtutor:id/editMyAnswer"));
        editTextObj2.setText("1234");


        int num3 =0;
        try {
            String textNum1 = num1.getText();
            String textNum2 = num2.getText();
            num3 = Integer.parseInt(textNum1) + Integer.parseInt(textNum2);
            editText.setText(String.valueOf(num3));
        } catch (UiObjectNotFoundException e) {
            e.printStackTrace();
        }
        takeScreenshot("screenshot-5.png");

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            mDevice.pressBack();
        }
        tuturObject = waitForObject(By.text("Tutor Answer"));
        tuturObject.click();

        UiObject2 tansObject = null;

        String tutorAnswer = null;

        while (tutorAnswer == null) {
            tansObject = waitForObject(By.res("com.slinetwork.mathtutor:id/editTutorAnswer"));
            tutorAnswer = tansObject.getText();
        }


        takeScreenshot("screenshot-6.png");

        Thread.sleep(10000);
    }

    private void openApp(String packageName) {
        Context context = InstrumentationRegistry.getInstrumentation().getContext();
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
    }
    UiObject2 waitForObject2(BySelector bySelector) {
        long timeBefore=0;
        long timeAfter=0;
        long waitTime = 30000;
        timeBefore = System.currentTimeMillis();
        timeAfter = timeBefore;
        UiObject2 object = null;
        while (object == null) {
            if ((timeAfter - timeBefore) > waitTime) {
                fail();
            } else {
                timeAfter = System.currentTimeMillis();
                try {
                    object = mDevice.findObject(bySelector);
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }
        return object;

    }
    private UiObject2 waitForObject(BySelector selector) throws InterruptedException {
        UiObject2 object = null;
        int timeout = 30000;
        int delay = 1000;
        long time = System.currentTimeMillis();
        while (object == null) {
            object = mDevice.findObject(selector);
            Thread.sleep(delay);
            if (System.currentTimeMillis() - timeout > time) {
                fail();
            }
        }
        return object;
    }
    private void takeScreenshot(String name) {
        Log.d("TEST", "takeScreenshot");
        String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
        String dir = String.format("%s/%s", path, "test-screenshots");
        File theDir = new File(dir);
        if (!theDir.exists()) {
            theDir.mkdir();
        }
        mDevice.takeScreenshot(new File(String.format("%s/%s", dir, name)));
    }
}
