package com.slinetwork.mathtutor.function;

import android.test.ActivityInstrumentationTestCase2;

import com.robotium.solo.Solo;
import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.activities.LoginActivity;
import com.slinetwork.mathtutor.activities.MathActivity;
import com.slinetwork.mathtutor.activities.StudentActivity;

/**
 * Created by wayne on 14/08/17.
 */

public class ButtonPressRobotiumSoloTest extends
        ActivityInstrumentationTestCase2<LoginActivity> {

        private Solo solo;

        public ButtonPressRobotiumSoloTest() {
            super(LoginActivity.class);
        }

        public void setUp() throws Exception {
            solo = new Solo(getInstrumentation(), getActivity());
        }


        @Override
        public void tearDown() throws Exception {
            solo.finishOpenedActivities();
        }

    public void testLoginButtonClick() throws Exception {

        solo.assertCurrentActivity("wrong activity", LoginActivity.class);

        solo.clickOnButton(solo
                .getString(R.string.login));

        solo.assertCurrentActivity("wrong activity", MathActivity.class);

        assertTrue(solo.waitForText("Tutor Answer"));


    }
}
