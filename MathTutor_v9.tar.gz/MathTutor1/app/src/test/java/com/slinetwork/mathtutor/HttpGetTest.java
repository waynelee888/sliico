package com.slinetwork.mathtutor;

import com.slinetwork.mathtutor.networks.HttpError;
import com.slinetwork.mathtutor.networks.HttpGetParam;
import com.slinetwork.mathtutor.networks.HttpManagerBase;
import com.slinetwork.mathtutor.networks.HttpResponse;
import com.slinetwork.mathtutor.networks.HttpStatus;
import com.slinetwork.mathtutor.networks.mocks.HttpManagerMock;

import org.junit.Before;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpGetTest implements HttpManagerBase.ResponseListener{
    HttpManagerMock httpManager;

    @Before
    public void setup() {
        httpManager = new HttpManagerMock();
        httpManager.setResponseListener(this);
    }

    @Test
    public void testHttpGetMethod() {
        HttpGetParam httpGetParam = new HttpGetParam();
        try {
            URL url = new URL("http://www.google.com");
            httpGetParam.setUrl(url);
            httpManager.setHttpGetMethod(httpGetParam);
            HttpResponse httpResponse = httpManager.httpExecute();
            assertNotNull(httpResponse);
            assertTrue(httpResponse.getHttpError().getError() == HttpError.ErrorType.ERROR_TYPE_NONE);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onHttpError(HttpError httpError) {

    }

    @Override
    public void onHttpSuccess(HttpResponse httpResponse) {

    }

    @Override
    public void onHttpStatus(HttpStatus httpStatus) {

    }
}
