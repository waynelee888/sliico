package com.slinetwork.mathtutor.function;

import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.activities.MathActivity;

import android.support.test.espresso.UiController;
import android.support.test.espresso.ViewAction;
import android.support.test.espresso.intent.rule.IntentsTestRule;
import android.support.test.espresso.matcher.BoundedMatcher;
import android.support.test.filters.LargeTest;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.atomic.AtomicReference;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.intent.Intents.assertNoUnverifiedIntents;
import static android.support.test.espresso.intent.Intents.intended;
import static android.support.test.espresso.intent.matcher.ComponentNameMatchers.hasShortClassName;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasExtra;
import static android.support.test.espresso.intent.matcher.IntentMatchers.toPackage;
import static android.support.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;

/**
 * Created by wayne on 09/08/17.
 */

@RunWith(AndroidJUnit4.class)
public class ButtonPressEspressoTest {
    private static  String answer = "";
    private static  String num1 = "";
    private static  String num2 = "";

    private static final String MESSAGE = "This is a test";
    private static final String PACKAGE_NAME = "com.example.myfirstapp";


    /* Instantiate an ActivityTestRule object. */
    @Rule
    public ActivityTestRule<MathActivity> mActivityRule =
            new ActivityTestRule<>(MathActivity.class);


    public static Matcher<View> textCapture(final AtomicReference<String> ref) {

        return new BoundedMatcher<View, EditText>(EditText.class) {
            @Override
            public void describeTo(Description description) {
                description.appendText("read value from edit text");
            }

            @Override
            public boolean matchesSafely(EditText textView) {
                ref.set(textView.getText().toString());
                return true;
            }
        };
    }

    public static ViewAction setTextEditText(final String value){
        return new ViewAction() {
            @SuppressWarnings("unchecked")
            @Override
            public Matcher<View> getConstraints() {
                return allOf(isDisplayed(), isAssignableFrom(EditText.class));
            }

            @Override
            public void perform(UiController uiController, View view) {
                ((EditText) view).setText(value);
            }

            @Override
            public String getDescription() {
                return "replace text";
            }
        };
    }

    @Test
    public void verify1Activity() {

        onView(withId(R.id.buttonAddition)).perform(click());

        onView(withId(R.id.editNum1))
                .perform(replaceText("1"), closeSoftKeyboard());
        onView(withId(R.id.editNum2))
                .perform(replaceText("2"), closeSoftKeyboard());
        onView(withId(R.id.editMyAnswer))
                .perform(typeText("3"), closeSoftKeyboard());
        onView(withId(R.id.buttonTutorAnswer)).perform(click());
        // Check that the text was changed.
        onView(withId(R.id.editTutorAnswer)).check(matches(withText("3")));


/*
        AtomicReference<String> ref = new AtomicReference<String>() ;
        textCapture(ref );

        num1 = ref.get();
        AtomicReference<String> ref2 = new AtomicReference<String>() ;
        textCapture(ref2 );

        num2 = ref2.get();
        int answer1 = Integer.parseInt(num1)+Integer.parseInt(num2);
        // Types a message into a EditText element.
        onView(withId(R.id.editMyAnswer))
                .perform(typeText(String.valueOf(answer1)), closeSoftKeyboard());

        onView(withId(R.id.buttonTutorAnswer)).perform(click());

        AtomicReference<String> ref3 = new AtomicReference<String>() ;
        textCapture(ref3 );

        int answer2 = Integer.parseInt(ref3.get());
*/




        // Verifies that the MathActivity received an intent
        // with the correct package name and message.
        /*
        intended(allOf(
                        hasComponent(hasShortClassName(".MathActivity")),
                        toPackage(PACKAGE_NAME),
                        null
                        )
                ); */

    }


    @Test
    public void verify2Activity() {

        onView(withId(R.id.buttonAddition)).perform(click());

        onView(withId(R.id.editNum1))
                .perform(replaceText("1"), closeSoftKeyboard());
        onView(withId(R.id.editNum2))
                .perform(replaceText("2"), closeSoftKeyboard());
        onView(withId(R.id.editMyAnswer))
                .perform(typeText("4"), closeSoftKeyboard());
        onView(withId(R.id.buttonTutorAnswer)).perform(click());
        // Check that the text was changed.
        onView(withId(R.id.editTutorAnswer)).check(matches(withText("")));



    }
}