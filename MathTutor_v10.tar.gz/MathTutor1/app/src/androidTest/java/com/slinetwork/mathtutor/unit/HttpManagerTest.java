package com.slinetwork.mathtutor.unit;

import android.support.test.InstrumentationRegistry;
import android.support.test.filters.SmallTest;
import android.support.test.runner.AndroidJUnit4;

import com.slinetwork.mathtutor.networks.HttpClientFactory;
import com.slinetwork.mathtutor.networks.HttpError;
import com.slinetwork.mathtutor.networks.HttpGetParam;
import com.slinetwork.mathtutor.networks.HttpManagerApacheClient;
import com.slinetwork.mathtutor.networks.HttpManagerBase;
import com.slinetwork.mathtutor.networks.HttpManagerOkHttpClient;
import com.slinetwork.mathtutor.networks.HttpPostParam;
import com.slinetwork.mathtutor.networks.HttpResponse;
import com.slinetwork.mathtutor.networks.HttpStatus;
import com.squareup.okhttp.MediaType;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static com.slinetwork.mathtutor.networks.HttpClientFactory.HttpClient.APACHE_DEFAULT_HTTP_CLIENT;
import static com.slinetwork.mathtutor.networks.HttpClientFactory.HttpClient.JAVA_NET_HTTP_CLIENT;
import static com.slinetwork.mathtutor.networks.HttpClientFactory.HttpClient.OK_HTTP_CLIENT;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by wayne on 12/08/17.
 */
@RunWith(AndroidJUnit4.class)
@SmallTest
public class HttpManagerTest implements HttpManagerBase.ResponseListener {
    HttpManagerBase httpManager;

    @Before
    public void setup() {
    }

    @Test
    public void testApacheClientGetMethod() {
        httpManager = HttpClientFactory.getHttpManager(InstrumentationRegistry.getTargetContext(), APACHE_DEFAULT_HTTP_CLIENT);
        httpManager.setResponseListener(this);
        HttpGetParam httpGetParam = new HttpGetParam();
        try {
            URL url = new URL("http://www.google.com");
            httpGetParam.setUrl(url);
            httpManager.setHttpGetMethod(httpGetParam);
            HttpResponse httpResponse = httpManager.httpExecute();
            assertNotNull(httpResponse);
            assertTrue(httpResponse.getHttpError().getError() == HttpError.ErrorType.ERROR_TYPE_NONE);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testApacheClientPostMethod() {
        httpManager = HttpClientFactory.getHttpManager(InstrumentationRegistry.getTargetContext(), APACHE_DEFAULT_HTTP_CLIENT);
        httpManager.setResponseListener(this);
        HttpPostParam httpPostParam = new HttpPostParam();
        try {
            URL url = new URL("http://androidexample.com/media/webservice/httppost.php");
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
            nameValuePairs.add(new BasicNameValuePair("name", "wayne"));
            nameValuePairs
                    .add(new BasicNameValuePair("email", "wm_hinut"));
            nameValuePairs.add(new BasicNameValuePair("user", "GOOGLE"));
            nameValuePairs.add(new BasicNameValuePair("pass",
                    "Google"));
            httpPostParam.setUrl(url);
            httpPostParam.setParams(nameValuePairs);
            httpManager.setHttpPostMethod(httpPostParam);
            HttpResponse httpResponse = httpManager.httpExecute();
            assertNotNull(httpResponse);
            assertTrue(httpResponse.getHttpError().getError() == HttpError.ErrorType.ERROR_TYPE_NONE);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testJavaNetClientGetMethod() {
        httpManager = HttpClientFactory.getHttpManager(InstrumentationRegistry.getTargetContext(), JAVA_NET_HTTP_CLIENT);
        httpManager.setResponseListener(this);
        HttpGetParam httpGetParam = new HttpGetParam();
        try {
            URL url = new URL("http://www.google.com");
            httpGetParam.setUrl(url);
            httpManager.setHttpGetMethod(httpGetParam);
            HttpResponse httpResponse = httpManager.httpExecute();
            assertNotNull(httpResponse);
            assertTrue(httpResponse.getHttpError().getError() == HttpError.ErrorType.ERROR_TYPE_NONE);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testJavaNetClientPostMethod() {
        httpManager = HttpClientFactory.getHttpManager(InstrumentationRegistry.getTargetContext(), JAVA_NET_HTTP_CLIENT);
        httpManager.setResponseListener(this);
        HttpPostParam httpPostParam = new HttpPostParam();
        try {
            URL url = new URL("http://androidexample.com/media/webservice/httppost.php");
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
            nameValuePairs.add(new BasicNameValuePair("name", "wayne"));
            nameValuePairs
                    .add(new BasicNameValuePair("email", "wm_hinut"));
            nameValuePairs.add(new BasicNameValuePair("user", "GOOGLE"));
            nameValuePairs.add(new BasicNameValuePair("pass",
                    "Google"));
            httpPostParam.setUrl(url);
            httpPostParam.setParams(nameValuePairs);
            httpManager.setHttpPostMethod(httpPostParam);
            HttpResponse httpResponse = httpManager.httpExecute();
            assertNotNull(httpResponse);
            assertTrue(httpResponse.getHttpError().getError() == HttpError.ErrorType.ERROR_TYPE_NONE);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }


    @Test
    public void testOkHttpClientGetMethod() {
        httpManager = HttpClientFactory.getHttpManager(InstrumentationRegistry.getTargetContext(), OK_HTTP_CLIENT);
        httpManager.setResponseListener(this);
        HttpGetParam httpGetParam = new HttpGetParam();
        try {
            URL url = new URL("http://www.google.com");
            httpGetParam.setUrl(url);
            httpManager.setHttpGetMethod(httpGetParam);
            HttpResponse httpResponse = httpManager.httpExecute();
            assertNotNull(httpResponse);
            assertTrue(httpResponse.getHttpError().getError() == HttpError.ErrorType.ERROR_TYPE_NONE);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testOkHttpClientPostMethod() {
        httpManager = HttpClientFactory.getHttpManager(InstrumentationRegistry.getTargetContext(), OK_HTTP_CLIENT);
        httpManager.setResponseListener(this);
        HttpPostParam httpPostParam = new HttpPostParam();
        try {
            URL url = new URL("http://androidexample.com/media/webservice/httppost.php");

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
            nameValuePairs.add(new BasicNameValuePair("name", "wayne"));
            nameValuePairs
                    .add(new BasicNameValuePair("email", "wm_hinut"));
            nameValuePairs.add(new BasicNameValuePair("user", "GOOGLE"));
            nameValuePairs.add(new BasicNameValuePair("pass",
                    "Google"));
            httpPostParam.setUrl(url);
            httpPostParam.setParams(nameValuePairs);

            httpManager.setHttpPostMethod(httpPostParam);
            HttpResponse httpResponse = httpManager.httpExecute();
            assertNotNull(httpResponse);
            assertTrue(httpResponse.getHttpError().getError() == HttpError.ErrorType.ERROR_TYPE_NONE);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onHttpError(HttpError httpError) {

    }

    @Override
    public void onHttpSuccess(HttpResponse httpResponse) {

    }

    @Override
    public void onHttpStatus(HttpStatus httpStatus) {

    }
}
