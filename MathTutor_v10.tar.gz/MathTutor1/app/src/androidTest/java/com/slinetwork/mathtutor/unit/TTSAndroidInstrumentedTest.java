package com.slinetwork.mathtutor.unit;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.support.test.InstrumentationRegistry;
import android.support.test.filters.SmallTest;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import com.slinetwork.mathtutor.utils.Util;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
/**
 * Created by wayne on 08/08/17.
 */
@RunWith(AndroidJUnit4.class)
@SmallTest
public class TTSAndroidInstrumentedTest {

    private Context instrumentationCtx;
    Boolean bSpeak = false;
    Util util;
    TextToSpeech tts;
    @Before
    public void setup() {
        instrumentationCtx = InstrumentationRegistry.getContext();

    }

    @Test
    public void talk() {
        TextToSpeech.OnInitListener ttslistener = new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if( status == TextToSpeech.SUCCESS ) {
                    bSpeak = true;
                } else {
                    bSpeak = false;
                }
                assertTrue(bSpeak);
                Util.sayText(tts, "hello world");
            }
        };
        tts = new TextToSpeech(instrumentationCtx,ttslistener);
    }


}
