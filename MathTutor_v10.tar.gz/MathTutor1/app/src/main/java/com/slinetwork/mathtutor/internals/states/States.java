package com.slinetwork.mathtutor.internals.states;

/**
 * Created by wayne on 08/08/17.
 */

public class States {
    public static enum Phone {
        PHONE_S0,
        PHONE_S1,
        PHONE_S2,
        PHONE_S3,
        PHONE_S4
    };
}
