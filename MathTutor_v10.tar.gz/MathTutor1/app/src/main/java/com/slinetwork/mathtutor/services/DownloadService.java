package com.slinetwork.mathtutor.services;

import android.app.Activity;
import android.app.IntentService;
import android.content.Intent;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by wayne on 24/07/17.
 */

public class DownloadService extends IntentService {
    private int result = Activity.RESULT_CANCELED;
    public static final String OUTPUT_NAME = "index.html";
    public static final String FNAME = "FNAME";
    public static final String URL_PATH = "URL";
    public static final String FILEPATH = "filepath";
    public static final String RESULT = "result";
    public static final String NOTIFICATION = "com.slinetwork.mathtutor.services.receiver";

    public DownloadService() {
        this("DownloadService");
    }
    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */
    public DownloadService(String name) {
        super(name);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        String fname = intent.getStringExtra(FNAME);
        String urlpath = intent.getStringExtra(URL_PATH);

        FileOutputStream fos = null;

        File output = new File(Environment.getExternalStorageDirectory(),
                fname);
        if (output.exists()) {
            output.delete();
        }

        URL url = null;
        try {
            url = new URL(urlpath);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        InputStream is = null;
        InputStreamReader reader =null;
        try {
            is = url.openConnection().getInputStream();
            reader = new InputStreamReader(is);
            fos = new FileOutputStream(output.getAbsolutePath());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int nRead=0;
        byte [] buffer = new byte[128];

        int next=-1;

        try {
            /*
            while ( (next = reader.read()) != -1) {
                fos.write(next);
            }
            */


            while ((nRead = is.read(buffer, 0, buffer.length))!= -1) {
                fos.write(buffer, 0, nRead);
            }


            result = Activity.RESULT_OK;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        publishResults(output.getAbsolutePath(), result);

    }

    private void publishResults(String path, int result) {
        Intent intent = new Intent(NOTIFICATION);
        intent.putExtra(FILEPATH, path);
        intent.putExtra(RESULT, result);

        sendBroadcast(intent);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);




    }
}
