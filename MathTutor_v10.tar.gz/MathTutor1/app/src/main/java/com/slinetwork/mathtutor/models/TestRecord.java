package com.slinetwork.mathtutor.models;

import com.slinetwork.mathtutor.activities.MathActivity;
import com.slinetwork.mathtutor.activities.MathActivity.MathOperation;

// Object Model
public class TestRecord {
	private MathActivity.MathOperation opType;
	private Integer num1;
	private String op;
	private Integer num2;
	private Integer testResult;
	private Integer tutorResult;
	
	public TestRecord() {};
	
	public TestRecord(MathActivity.MathOperation opType,
					  Integer num1,
					  String op,
					  Integer num2,
					  Integer testResult,
					  Integer tutorResult
					  ) {
		super();
		this.opType = opType;
		this.num1 = num1;
		this.op = op;
		this.num2 = num2;
		this.testResult = testResult;
		this.tutorResult = tutorResult;
	}
	
	public MathOperation getOpType() {return opType;};
	public Integer getNum1() {return num1;};
	public String getOp() {return op;};
	public Integer getNum2() {return num2;};
	public Integer getTestResult() {return testResult;};
	public Integer getTutorResult() {return tutorResult;};
	
	public String toString() {	
		return new String( num1 + " " + op + " " + num2 + " " + testResult + " " + tutorResult);
	}
}
