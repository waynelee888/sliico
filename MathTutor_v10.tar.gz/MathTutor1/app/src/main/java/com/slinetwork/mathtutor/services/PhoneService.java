package com.slinetwork.mathtutor.services;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.support.annotation.BinderThread;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;

import com.slinetwork.mathtutor.models.PhoneNameNumber;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.ServiceConfigurationError;

/**
 * Created by wayne on 07/08/17.
 */

public class PhoneService extends Service {
    public static final String PHONE_SERVICE = "com.slinetwork.mathtutor.PHONE_SERVICE";
    public static final String PHONE_NOTIFY = "com.slinetwork.mathtutor.services.PhoneService.PHONE_NOTIFY";
    public static final String PHONE_FILE_NOTIFY = "com.slinetwork.mathtutor.services.PhoneService.PHONE_FILE_NOTIFY";
    public static final String PHONE_CACHE_NOTIFY = "com.slinetwork.mathtutor.services.PhoneService.PHONE_CACHE_NOTIFY";
    public static final String PHONE_LIST = "PHONE_LIST";
    public static final String PHONE_FILE_NAME = "phone_list.txt";

    public PhoneService() {}

    public static class PhoneBinder extends Binder {
        public PhoneService getPhoneService() {
            return new PhoneService();
        }

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new PhoneBinder();
    }

    public String getNumber(final Context context, Cursor cursor) {

        if (cursor == null) {
            return null;
        }

        int indexNumber = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
        String phone = null;

        try {
            if (cursor.moveToFirst()) {
                do {

                    // column index of the phone number
                    phone = cursor.getString(indexNumber);
                    break;


                }
                while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }
        return phone;
    }


    public void getPhones(final Context context) {

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {

                final ArrayList<PhoneNameNumber> phoneList = new ArrayList<>(0);
                Intent intent = new Intent(PhoneService.PHONE_NOTIFY);
                intent.putParcelableArrayListExtra(PhoneService.PHONE_LIST,phoneList);


                String[] projection    = new String[] {
                                                ContactsContract.Contacts._ID,
                                                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME};

                Cursor cursor = context.getContentResolver().query(
                        ContactsContract.Contacts.CONTENT_URI,
                        projection, null, null, null );
                if (cursor == null) {
                    return;
                }

                int indexName = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

                String name;
                String number;

                try {


                    if (cursor.moveToFirst()) {
                        do {

                                    name = cursor.getString(indexName);
                            //if (name.equals("Sravan")) {
                                int in = cursor.getColumnIndex(ContactsContract.Contacts._ID);
                                String contactId =
                                        cursor.getString(in);

                                projection = new String[] {ContactsContract.CommonDataKinds.Phone.NUMBER};

                                Cursor phones = context.getContentResolver().query(
                                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                        projection, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[] {contactId}, null);
                                number = getNumber(context,phones);

                            // }

                            PhoneNameNumber pnn = new PhoneNameNumber();
                            pnn.name = name;
                            pnn.number = number;
                            phoneList.add(pnn);
                        }
                        while (cursor.moveToNext());
                    }
                    LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
                } finally {
                    cursor.close();
                }


            }
        });
        t.start();

    }



}
