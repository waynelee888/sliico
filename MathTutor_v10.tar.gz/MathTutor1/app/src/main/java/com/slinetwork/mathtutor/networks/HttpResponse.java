package com.slinetwork.mathtutor.networks;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpResponse {
    HttpError httpError;
    public void setHttpError(HttpError httpError) {
        this.httpError = httpError;
    }
    public HttpError getHttpError() {
        return httpError;
    }
}
