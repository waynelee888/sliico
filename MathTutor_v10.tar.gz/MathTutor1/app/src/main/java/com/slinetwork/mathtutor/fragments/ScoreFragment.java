package com.slinetwork.mathtutor.fragments;


import android.content.ContentValues;
import android.content.Context;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.dao.TestRecordDao;
import com.slinetwork.mathtutor.databases.TestRecordDB;
import com.slinetwork.mathtutor.models.TestRecord;
import com.slinetwork.mathtutor.utils.DatabaseUtil;

/**
 * Created by wayne on 19/08/17.
 */

public class ScoreFragment extends Fragment {
    public static final String TAG = ScoreFragment.class.getSimpleName();
    public static final String SAVE_TAG = "NAME";

    String name = "Pauline";

    public String getName() {
        return name;
    }

    @Override
    public void setRetainInstance(boolean retain) {
        super.setRetainInstance(retain);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.score, container, false);

        ContentValues contentValues = new ContentValues();
        contentValues.put("SFS", "Paul");
        contentValues.put("SFBS", new Byte("91"));
        byte value = 32;
        contentValues.put("SFBi", new Byte(value));
        contentValues.put("SFBF", new Float(1.230));
        byte[] valueArr = {10, 20};
        contentValues.put("SFBa", valueArr);

        SQLiteQueryBuilder sqLiteQueryBuilder = new SQLiteQueryBuilder();
        SQLiteDatabase db = TestRecordDB.getInstance(this.getContext()).getReadableDatabase();
        sqLiteQueryBuilder.setTables(TestRecordDao.TABLE_REPORT);
        Cursor c = sqLiteQueryBuilder.query(db,
                                            new String[]{TestRecordDao.KEY_RES1,
                                            TestRecordDao.KEY_NUM1,
                                            TestRecordDao.KEY_NUM2,
                                            TestRecordDao.KEY_RES2,
                                            TestRecordDao.KEY_OP},
                                            "op=?",
                                            new String[]{"-"},
                                            null, null, null);
        if (c != null && c.moveToFirst()) {
            do {

                Log.d("SF", c.getString(c.getColumnIndex(TestRecordDao.KEY_NUM1)) +
                        c.getString(c.getColumnIndex(TestRecordDao.KEY_OP)) +
                        c.getString(c.getColumnIndex(TestRecordDao.KEY_NUM2)) +
                        c.getString(c.getColumnIndex(TestRecordDao.KEY_RES1)) +
                        c.getString(c.getColumnIndex(TestRecordDao.KEY_RES2)));
            } while (c.moveToNext());
        }
        SQLiteDatabase dbw = TestRecordDB.getInstance(this.getContext()).getReadableDatabase();

        TestRecordDao testRecordDao = new TestRecordDao(this.getContext());

        ContentValues values = new ContentValues();
        values.put(TestRecordDao.KEY_NUM1, "1");
        values.put(TestRecordDao.KEY_OP, "+");
        values.put(TestRecordDao.KEY_NUM2, "2");
        values.put(TestRecordDao.KEY_RES1, "3");
        values.put(TestRecordDao.KEY_RES2, "3");
        dbw.insert(TestRecordDao.TABLE_REPORT, null, values);

        SQLiteStatement sqLiteStatement = dbw.compileStatement("update "
                + TestRecordDao.TABLE_REPORT
                + " set " + TestRecordDao.KEY_OP + "=?, "
                + TestRecordDao.KEY_NUM1 + "=?"
                + " where "
                + TestRecordDao.KEY_OP + "=? and "
                + TestRecordDao.KEY_NUM1 + "=? and "
                + TestRecordDao.KEY_NUM2 + "=?");
        sqLiteStatement.bindString(1, "-");
        sqLiteStatement.bindString(2, "234");
        sqLiteStatement.bindString(3, "+");
        sqLiteStatement.bindString(4, "1");
        sqLiteStatement.bindString(5, "2");

        try {
            sqLiteStatement.executeUpdateDelete();

        } catch (SQLException sqlException) {
            sqlException.toString();

        }

        return view;
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);

        if (savedInstanceState != null) {
            name = savedInstanceState.getString(SAVE_TAG);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(SAVE_TAG, name);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        Log.d("LACC", "onConfigurationChanged from fragment");
        super.onConfigurationChanged(newConfig);
        name = "Susan";
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }
}
