package com.slinetwork.mathtutor.business;

/**
 * Created by wayne on 25/07/17.
 */

public class GroupPlay {
    // Create groups of people to to multiplay
}
