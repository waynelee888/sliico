package com.slinetwork.mathtutor.internals.managers;

import com.slinetwork.mathtutor.internals.states.States;

import static com.slinetwork.mathtutor.internals.states.States.Phone.PHONE_S2;

/**
 * Created by wayne on 08/08/17.
 */

public class StateManager {
    States states;
    public StateManager() {
        states = new States();
    }
    public void handlePhoneState(ThreadManager threadManager, States.Phone state, Runnable run) {
        if (state == PHONE_S2) {
            threadManager.addWork(run);
        }

    }

}
