package com.slinetwork.mathtutor.networks;

import android.content.Context;
import android.os.Build;
import android.os.Environment;

import org.apache.http.*;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import cz.msebera.android.httpclient.*;

import static com.slinetwork.mathtutor.networks.HttpClientFactory.context;

/**
 * Created by wayne on 12/08/17.
 */

class HttpManagerJavaNetClient extends HttpManagerBase {
    HttpURLConnection urlConnection;
    Context context;

    public HttpManagerJavaNetClient() {
    }
    public HttpManagerJavaNetClient(Context context) {
        this.context = context;
    }

    @Override
    public HttpResponse httpExecute() {
        HttpResponse httpResponse = new HttpResponse();

        HttpParams httpParams = httpRequest.getHttpParams();
        URL url = httpParams.url;

        if (httpRequest.getHttpMethods() instanceof HttpGetMethod) {

            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
                File file;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    String outputfile = context.getFilesDir() + File.separator + "httptest.html";
                    file = new File(outputfile);
                } else {
                    file = new File(Environment.getExternalStorageDirectory(), File.separator + "httptest.html");
                }
                if (file.exists()) {
                    file.delete();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                byte[] buffer = new byte[128];
                int len = 128;
                int actual = 0;
                while ((actual = inputStream.read(buffer, 0, len)) != -1) {
                    bufferedOutputStream.write(buffer, 0, actual);
                }
                bufferedOutputStream.flush();
                bufferedOutputStream.close();
                inputStream.close();
                HttpError httpError = new HttpError();
                httpError.errorType = HttpError.ErrorType.ERROR_TYPE_NONE;
                httpResponse.setHttpError(httpError);
                responseListener.onHttpSuccess(httpResponse);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
        } else if (httpRequest.getHttpMethods() instanceof HttpPostMethod) {

            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(10000);
                urlConnection.setConnectTimeout(15000);
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                urlConnection.setChunkedStreamingMode(0);

                OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
                List<NameValuePair> pairs = httpParams.getParams();
                StringBuilder stringBuilder = new StringBuilder(1);

                for (NameValuePair n : pairs) {
                    String aPair = n.getName() + "=" + n.getValue() + "&";
                    stringBuilder.append(aPair);
                }
                String postParam = stringBuilder.toString();
                postParam.substring(0, postParam.length() - 1);
                out.write(postParam.getBytes());

                out.flush();
                out.close();


                urlConnection.connect();
                InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                File file;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    String outputfile = context.getFilesDir() + File.separator + "httptest.html";
                    file = new File(outputfile);
                } else {
                    file = new File(Environment.getExternalStorageDirectory(), File.separator + "httptest.html");
                }
                if (file.exists()) {
                    file.delete();
                }
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);

                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    outputStreamWriter.write(line, 0, line.length());
                }
                outputStreamWriter.flush();
                outputStreamWriter.close();
                bufferedReader.close();
                HttpError httpError = new HttpError();
                httpError.errorType = HttpError.ErrorType.ERROR_TYPE_NONE;
                httpResponse.setHttpError(httpError);
                responseListener.onHttpSuccess(httpResponse);
            } catch (IOException e1) {
                e1.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }

        }

        return httpResponse;

    }
}