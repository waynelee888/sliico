package com.slinetwork.mathtutor.networks;

import org.apache.http.NameValuePair;

import java.net.URL;
import java.util.List;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpPostParam extends HttpParams {

    @Override
    public void setUrl(URL url) {
        this.url = url;
    }

    public void setParams(List<NameValuePair> pairs) {
        this.pairs.addAll(pairs);
    }
    public List<NameValuePair> getParams() {
        return pairs;
    }
}
