package com.slinetwork.mathtutor.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.slinetwork.mathtutor.MathTutor;
import com.slinetwork.mathtutor.activities.MathActivity;
import com.slinetwork.mathtutor.models.TestRecord;

public final class TestRecordDB extends SQLiteOpenHelper {
	
	private static final String TAG = "TestReportDB";
	
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "TestReport.db";
 	
	private static final String TABLE_REPORT = "test_report";

	private static final String KEY_ID = "id";
	private static final String KEY_NUM1 = "num1";
    private static final String KEY_OP = "op";
	private static final String KEY_NUM2 = "num2";
	private static final String KEY_RES1 = "test_result";
	private static final String KEY_RES2 = "tutor_result";
	
	private static final String[] COLUMNS = {KEY_ID,KEY_NUM1,KEY_OP,KEY_NUM2,KEY_RES1,KEY_RES2};

	static TestRecordDB testRecordDB;

	//    public TestRecordDB() {
//        this(MathTutor.getContext());
//    }
	public static TestRecordDB getInstance(Context context) {

		synchronized (new Object()) {
			if (testRecordDB == null) {
				testRecordDB = new TestRecordDB(context);
			}
		}
		return testRecordDB;

	}
    public TestRecordDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
	
	public TestRecordDB(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
        // SQL statement to create tables
        String CREATE_REPORT_TABLE = "CREATE TABLE test_report ( " +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " + 
                "num1 TEXT, "+
                "op TEXT, "+
                "num2 TEXT, "+
                "test_result TEXT,"+
                "tutor_result TEXT )";

        // create tables
        db.execSQL(CREATE_REPORT_TABLE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Drop older books table if existed
        db.execSQL("DROP TABLE IF EXISTS test_report");

        // create fresh adds table
        this.onCreate(db);
		
	}

    


	public interface TestRecordFieldNames {
		String KEY_ID = "id";
		String KEY_NUM1 = "num1";
        String KEY_OP = "op";
		String KEY_NUM2 = "num2";
		String KEY_RES1 = "test_result";
		String KEY_RES2 = "tutor_result";

	}
	public interface TestRecordTableNames {
		String TABLE_REPORT = "test_report";

	}
}
