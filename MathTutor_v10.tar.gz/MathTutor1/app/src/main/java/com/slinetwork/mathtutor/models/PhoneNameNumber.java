package com.slinetwork.mathtutor.models;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by wayne on 08/08/17.
 */

public class PhoneNameNumber implements Parcelable {
    public String name;
    public String number;
    public PhoneNameNumber(String name, String number) {this.name = name; this.number =number;};

    public PhoneNameNumber() {}
    public PhoneNameNumber(Parcel in) {
        readFromParcel(in);
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(number);

    }

    private void readFromParcel(Parcel in) {
        name = in.readString();
        number = in.readString();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        @Override
        public PhoneNameNumber createFromParcel(Parcel in) {
            return new PhoneNameNumber(in);
        }

        @Override
        public PhoneNameNumber[] newArray(int size) {
            return new PhoneNameNumber[size];
        }
    };
}

