package com.slinetwork.mathtutor.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.support.annotation.Nullable;
import android.util.Log;

import com.slinetwork.mathtutor.activities.MathActivity;
import com.slinetwork.mathtutor.databases.TestRecordDB;
import com.slinetwork.mathtutor.models.TestRecord;

import java.sql.PreparedStatement;
import java.util.ArrayList;

/**
 * Created by wayne on 25/07/17.
 */

public class TestRecordDao implements TestRecordDB.TestRecordFieldNames, TestRecordDB.TestRecordTableNames {
    private static final String TAG = "TestRecordDao";

    private TestRecordDB testRecordDB = null;
    private SQLiteDatabase db;
    private SQLiteDatabase dbw;
    private SQLiteStatement insertStatement;
    private static String INSERT_SQL;

    public TestRecordDao(Context context){
        testRecordDB = TestRecordDB.getInstance(context);
        db = testRecordDB.getReadableDatabase();
        dbw = testRecordDB.getWritableDatabase();

    }
    public boolean databaseAccessible() {
        if (db != null) {
            return  true;
        }
        return false;
    }

    public long insert(TestRecord trec){
        /*
        // 1. get reference to writable DB
        SQLiteDatabase db = testRecordDB.getWritableDatabase();

        // 2. create ContentValues to add key "column"/value
        ContentValues values = new ContentValues();
        values.put(KEY_NUM1, trec.getNum1());
        values.put(KEY_OP, trec.getOp());
        values.put(KEY_NUM2, trec.getNum2());
        values.put(KEY_RES1, trec.getTestResult());
        values.put(KEY_RES2, trec.getTutorResult());

        // 3. insert
            db.insert(TABLE_REPORT, // table
                    null, //nullColumnHack
                    values); // key/value -> keys = column names/ values = column values

        // 4. close
        db.close();
        */
        INSERT_SQL = "insert into " + TABLE_REPORT + " (num1, op, num2, test_result, tutor_result) values (?,?,?,?,?)";

        insertStatement = dbw.compileStatement(INSERT_SQL);

        insertStatement.bindLong(1, trec.getNum1());
        insertStatement.bindString(2, trec.getOp());
        insertStatement.bindLong(3, trec.getNum2());
        insertStatement.bindLong(4, trec.getTestResult());
        insertStatement.bindLong(5, trec.getTutorResult());

        return insertStatement.executeInsert();
    }



    public Cursor getTestRecordsForAdds(){
        return getTestRecords(MathActivity.MathOperation.ADDITION);
    }
    public Cursor getTestRecordsForSubs(){
        return getTestRecords(MathActivity.MathOperation.SUBTRACTION);
    }
    public Cursor getTestRecordsForMults(){
        return getTestRecords(MathActivity.MathOperation.MULTIPLICATION);
    }
    public Cursor getTestRecordsForDivs(){
        return getTestRecords(MathActivity.MathOperation.DIVISION);
    }

    public Cursor getTestRecordsForAll(){
        return getTestRecords(MathActivity.MathOperation.ALL);
    }

    public Cursor getTestRecords(MathActivity.MathOperation mOp) {

        // query(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy, String limit)

        String[] columns = new String[] {
                "rowid as _id", KEY_ID, KEY_NUM1, KEY_OP, KEY_NUM2, KEY_RES1, KEY_RES2
        };
        String whereClause = "op = ?";


        String[] whereArgs = null;

        if (MathActivity.MathOperation.ADDITION==mOp) {
            whereArgs = new String[] {"+"};
        } else if (MathActivity.MathOperation.SUBTRACTION==mOp) {
            whereArgs = new String[] {"-"};
        } else if (MathActivity.MathOperation.MULTIPLICATION==mOp) {
            whereArgs = new String[] {"x"};
        } else if (MathActivity.MathOperation.DIVISION==mOp) {
            whereArgs = new String[] {"/"};
        } else if (MathActivity.MathOperation.ALL==mOp) {
            whereClause = null;
        }

        String orderBy = "id";

        Cursor c =  db.query(TABLE_REPORT, columns, whereClause, whereArgs,
                null, null, orderBy);

        return c;
    }

    public Cursor getTestRecords(int id) {
        return null;
    }

    public Cursor getTestRecords(String[] projection, String sel, String [] args, String ord) {

        Cursor c =  db.query(TABLE_REPORT, projection, sel, args,
                null, null, ord);
        return c;
    }

        public Cursor getTestRecords(MathActivity.MathOperation mOp, int a){

        String buildSQL = "SELECT rowid _id, * FROM ";
        buildSQL += TABLE_REPORT;

        if (MathActivity.MathOperation.ADDITION==mOp) {
            buildSQL += " WHERE op = ";
            buildSQL += "'+'";
        } else if (MathActivity.MathOperation.SUBTRACTION==mOp) {
            buildSQL += " WHERE op = ";
            buildSQL += "'-'";
        } else if (MathActivity.MathOperation.MULTIPLICATION==mOp) {
            buildSQL += " WHERE op = ";
            buildSQL += "'x'";
        } else if (MathActivity.MathOperation.DIVISION==mOp) {
            buildSQL += " WHERE op = ";
            buildSQL += "'/'";
        } else if (MathActivity.MathOperation.ALL==mOp) {
        }

        SQLiteDatabase db = testRecordDB.getReadableDatabase();

        if (!isTableExists(TABLE_REPORT, db)) {
            String CREATE_REPORT_SUB_TABLE = "CREATE TABLE test_report ( " +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "num1 TEXT, "+
                    "num2 TEXT, "+
                    "test_result TEXT,"+
                    "tutor_result TEXT )";
            // create tables
            db.execSQL(CREATE_REPORT_SUB_TABLE);
        }

        Log.d(TAG, "getTestRecords SQL: " + buildSQL);
        return db.rawQuery(buildSQL, null);
    }


    public boolean isTableExists(String tableName, SQLiteDatabase db) {
        Cursor cursor = db.rawQuery("select DISTINCT tbl_name from sqlite_master where tbl_name = '"+tableName+"'", null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                cursor.close();
                return true;
            }
            cursor.close();
        }
        return false;
    }
    /*
    public TestRecord getRecord(int id) {

    }
    public ArrayList<TestRecord> getAllRecord() {

    }
    public void delete(int id) {

    }
    */
}
