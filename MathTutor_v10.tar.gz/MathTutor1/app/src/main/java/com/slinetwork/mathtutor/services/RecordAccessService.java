package com.slinetwork.mathtutor.services;

import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import com.slinetwork.mathtutor.dao.TestRecordDao;
import com.slinetwork.mathtutor.databases.TestRecordDB;
import com.slinetwork.mathtutor.models.TestRecord;

public class RecordAccessService extends Service {

	private static final String TAG = "RecordAccessService";
	private TestRecordDao mTR;
	private final IBinder mRSBinder = new RSBinder();


	@Override
	public IBinder onBind(Intent intent) {		
		return mRSBinder;
	}

	public class RSBinder extends Binder {
		public RecordAccessService getService() {
			return RecordAccessService.this;
		}		
	}
	
	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		Log.d(TAG, "onStart");
		// getTRDB();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.d(TAG, "onStartCommand");
		super.onStartCommand(intent, flags, startId);
		return Service.START_STICKY;
	}

	private boolean getTRDB() {
		if (null == mTR) {
			mTR = new TestRecordDao(this.getApplicationContext());
		} 
		return true;
	}
	
	public boolean logTest(TestRecord trec) {
		if (null != mTR) {
			mTR.insert(trec);
		}		
		return true;
		
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Log.d(TAG, "onCreate");
		getTRDB();
	}

	public Cursor readAddsTable() {
		Cursor addsCursor = null;
		if (null != mTR) {
			addsCursor = mTR.getTestRecordsForAdds();			
		}
		return addsCursor;
	}

	public Cursor readSubsTable() {
		Cursor addsCursor = null;
		if (null != mTR) {
			addsCursor = mTR.getTestRecordsForSubs();			
		}
		return addsCursor;
	}

	public Cursor readMultsTable() {
		Cursor addsCursor = null;
		if (null != mTR) {
			addsCursor = mTR.getTestRecordsForMults();			
		}
		return addsCursor;
	}

	public Cursor readDivsTable() {
		Cursor addsCursor = null;
		if (null != mTR) {
			addsCursor = mTR.getTestRecordsForDivs();			
		}
		return addsCursor;
	}

	public Cursor readAllTable() {
		Cursor allCursor = null;
		if (null != mTR) {
			allCursor = mTR.getTestRecordsForAll();
		}
		return allCursor;
	}
}
