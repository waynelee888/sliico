package com.slinetwork.mathtutor.networks;

import android.content.Context;
import android.os.Build;
import android.os.Environment;

import com.slinetwork.mathtutor.utils.Const;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URISyntaxException;
import java.net.URL;

import static com.slinetwork.mathtutor.networks.HttpClientFactory.context;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpManagerApacheClient extends HttpManagerBase {
    HttpClient httpClient;
    Context context;
    public HttpManagerApacheClient() {
        httpClient = new DefaultHttpClient();
    }

    public HttpManagerApacheClient(Context context) {

        this.context = context;
        httpClient = new DefaultHttpClient();
    }


    public HttpManagerApacheClient(Context context, org.apache.http.params.HttpParams hp) {
        this.context = context;

        httpClient = new DefaultHttpClient(hp);
    }
    public HttpManagerApacheClient(Context context, ClientConnectionManager ccm, org.apache.http.params.HttpParams hp) {
        httpClient = new DefaultHttpClient(ccm, hp);
        this.context = context;

    }




    public HttpResponse httpExecute() {
        HttpResponse httpResponse = new HttpResponse();

        try {
            HttpParams httpParams = httpRequest.getHttpParams();
            URL url = httpParams.url;

            if (httpRequest.getHttpMethods() instanceof HttpGetMethod) {

                HttpGet httpGet = new HttpGet(url.toURI());
                org.apache.http.HttpResponse response = httpClient.execute(httpGet);
                HttpEntity httpEntity = response.getEntity();
                StatusLine statusLine = response.getStatusLine();
                if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
                    HttpError httpError = new HttpError();
                    httpError.errorType = HttpError.ErrorType.ERROR_TYPE_NONE;
                    httpResponse.setHttpError(httpError);

                    InputStream inputStream = httpEntity.getContent();
                    //BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
                    File file;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                        String outputfile = context.getFilesDir() + File.separator + "httptest.html";
                        file = new File(outputfile);
                    } else {
                        file = new File(Environment.getExternalStorageDirectory(), File.separator + "httptest.html");
                    }                    if (file.exists()) {
                        file.delete();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                    byte[] buffer = new byte[128];
                    int len = 128;
                    int actual = 0;
                    while ((actual = inputStream.read(buffer, 0, len)) != -1) {
                        bufferedOutputStream.write(buffer, 0, actual);
                    }
                    bufferedOutputStream.flush();
                    bufferedOutputStream.close();
                    inputStream.close();
                    responseListener.onHttpSuccess(httpResponse);

                } else {
                    HttpError httpError = new HttpError();
                    httpError.errorType = HttpError.ErrorType.ERROR_TYPE_BAD_CONN;
                    httpResponse.setHttpError(httpError);
                    responseListener.onHttpError(httpError);


                }

            } else if (httpRequest.getHttpMethods() instanceof HttpPostMethod) {
                HttpPost httpPost = new HttpPost(url.toURI());
                httpPost.setEntity(new UrlEncodedFormEntity(httpParams.getParams()));

                org.apache.http.HttpResponse response = httpClient.execute(httpPost);
                HttpEntity httpEntity = response.getEntity();
                StatusLine statusLine = response.getStatusLine();
                if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
                    HttpError httpError = new HttpError();
                    httpError.errorType = HttpError.ErrorType.ERROR_TYPE_NONE;
                    httpResponse.setHttpError(httpError);

                    InputStream inputStream = httpEntity.getContent();
                    //BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
                    File file;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                        String outputfile = context.getFilesDir() + File.separator + "httptest.html";
                        file = new File(outputfile);
                    } else {
                        file = new File(Environment.getExternalStorageDirectory(), File.separator + "httptest.html");
                    }
                    if (file.exists()) {
                        file.delete();
                    }
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);

                    String line;

                    while ((line = bufferedReader.readLine()) != null) {
                        outputStreamWriter.write(line, 0, line.length());
                    }
                    outputStreamWriter.flush();
                    outputStreamWriter.close();
                    bufferedReader.close();
                    responseListener.onHttpSuccess(httpResponse);

                } else {
                    HttpError httpError = new HttpError();
                    httpError.errorType = HttpError.ErrorType.ERROR_TYPE_BAD_CONN;
                    httpResponse.setHttpError(httpError);
                    responseListener.onHttpError(httpError);

                }
            }


        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return httpResponse;
    }
}

