package com.slinetwork.mathtutor.networks.mocks;

import com.slinetwork.mathtutor.networks.HttpError;
import com.slinetwork.mathtutor.networks.HttpManagerBase;
import com.slinetwork.mathtutor.networks.HttpResponse;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpManagerMock extends HttpManagerBase {

    public HttpResponse httpExecute() {
        HttpResponse httpResponse = new HttpResponse();
        HttpError httpError = new HttpError();
        httpError.setError(HttpError.ErrorType.ERROR_TYPE_NONE);
        httpResponse.setHttpError(httpError);
        return httpResponse;

    };
}
