package com.slinetwork.mathtutor.networks;

/**
 * Created by wayne on 12/08/17.
 */

public abstract class HttpMethods {
    public enum HttpType {
        HTTP_METHODS_GET,
        HTTP_METHODS_POST,
        HTTP_METHODS_OPTIONS,
        HTTP_METHODS_HEAD,
        HTTP_METHODS_PUT,
        HTTP_METHODS_DELETE,
        HTTP_METHODS_TRACE
    };
}
