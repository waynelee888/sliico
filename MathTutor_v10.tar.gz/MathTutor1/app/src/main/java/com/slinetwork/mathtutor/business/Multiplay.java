package com.slinetwork.mathtutor.business;

/**
 * Created by wayne on 25/07/17.
 */

public class Multiplay {
    // enable multiple people play this app (do the test) on the same phone and on different devices connected.
    // use threadpool to spong thread for each person
}
