package com.slinetwork.mathtutor.networks;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpStatus {
    HttpStatus.StatusType statusType;
    public enum StatusType {
        STATUS_TYPE_NONE,
        STATUS_TYPE_TIMEOUT
    };
}
