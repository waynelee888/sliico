package com.slinetwork.mathtutor.activities;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.slinetwork.mathtutor.R;
import com.slinetwork.mathtutor.dao.TestRecordDao;
import com.slinetwork.mathtutor.fragments.ScoreFragment;
import com.slinetwork.mathtutor.models.LoginCredential;
import com.slinetwork.mathtutor.presenters.LoginPresenter;
import com.slinetwork.mathtutor.providers.ScoreProvider;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by wayne on 11/08/17.
 */

public class LoginActivity extends AppCompatActivity implements LoginPresenter.LoginValidater {
    public static final String SAVE_TAG = "NAME";
    private LoginCredential credential = null;
    Button login = null;
    LoginPresenter presenter;
    final int MY_PERMISSIONS_REQUEST_WRITE_EXT = 2;
    ByteArrayOutputStream baos;
    ActivityState state = ActivityState.ORIGINAL;
    ActivityState state2 = ActivityState.ORIGINAL;
    HashMap<Integer, String> hashMap;

    enum ActivityState {

        ROTATED("ROTATED"),
        ORIGINAL("ORIGINAL");


        private String name;
        ActivityState(String name) {
            this.name = name;
        }
        @Override
        public String toString() {
            return name;
        }
    }
    @Override
    public Object onRetainCustomNonConfigurationInstance() {
        return this;
    }

    @Override
    public Object getLastCustomNonConfigurationInstance() {
        return super.getLastCustomNonConfigurationInstance();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        Log.d("LACC", "onConfigurationChanged");
        super.onConfigurationChanged(newConfig);
        state = ActivityState.ROTATED;
        state2 = ActivityState.ROTATED;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(SAVE_TAG, state2.name());
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (savedInstanceState!= null) {
            String name = savedInstanceState.getString(SAVE_TAG);
            state2 = ActivityState.valueOf(name);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        // requestWindowFeature(Window.FEATURE_ACTION_BAR);
        super.onCreate(savedInstanceState);



        state = ActivityState.ORIGINAL;
        state2 = ActivityState.ORIGINAL;
        LoginActivity prevAct = (LoginActivity) getLastCustomNonConfigurationInstance();
        if (prevAct != null) {
            state = prevAct.state;
        }

        if (Build.VERSION.SDK_INT <= 18) {

            if (Build.VERSION.SDK_INT < 16)//before Jelly Bean Versions
            {
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);
            }
            else // Jelly Bean and up
            {
                View decorView = getWindow().getDecorView();
                // Hide the status bar.
                int ui = View.SYSTEM_UI_FLAG_FULLSCREEN;
                decorView.setSystemUiVisibility(ui);

                //Hide actionbar
                ActionBar actionBar = getSupportActionBar();
                if (actionBar != null) {
                    actionBar.hide();
                }
            }

        }

        setContentView(R.layout.login_page);
        presenter = new LoginPresenter(this);
        initUI();

        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Log.d("BLE", "FEATURE_BLUETOOTH_LE");
        }

        hashMap = new HashMap<>();
        hashMap.put(1, "A");
        hashMap.put(3, "B");
        hashMap.put(2, "C");
        Set<Map.Entry<Integer, String>> entries = hashMap.entrySet();
        hashMap.keySet();

        for (Map.Entry m : hashMap.entrySet()) {
            m.getKey();
            m.getValue();

        }

        Set keys = hashMap.keySet();
        Iterator<Integer> ii = keys.iterator();
        while (ii.hasNext()) {
            int i = ii.next().intValue();
        }

        Hashtable<String, Integer> hashtable = new Hashtable<>(1);
        hashtable.put("A", 1);
        Set<Map.Entry<String, Integer>> entrySet = hashtable.entrySet();
        for (Map.Entry<String, Integer> entry : entrySet) {
            entry.getKey();
            entry.getValue();
        }

        Comparator<Integer> comparator = new Comparator<Integer>() {
            @Override
            public int compare(Integer lhs, Integer rhs) {
                return lhs < rhs ? -1 : lhs == rhs ? 0 : 1;
            }
        };

        List<Integer> age = new ArrayList<Integer>(hashMap.keySet());

        Collections.sort(age, comparator);

        // int [] numbers = {-1, 0, -5, 2, 100, 10};
        // int[] numbers = {-1, -5, -2};
        int[] numbers = {-1, -2, -5, 100};
        int biggest = numbers[0];
        int second = biggest;
        for (int i = 0; i < numbers.length; i++) {
            if (biggest < numbers[i]) {
                second = biggest;
                biggest = numbers[i];
            } else if (second < numbers[i]) {
                second = numbers[i];
            } else if (second == biggest) {
                second = numbers[i];
            }
        }
        Log.d("TEST", "b=" + biggest + " s=" + second);

        People[] peoples = new People[5];
        for (int i = 0; i < peoples.length; i++) {
            peoples[i] = new People();
        }
        peoples[0].age = 10;
        peoples[0].name = new String("Pabc");
        peoples[3].age = 10;
        peoples[3].name = new String("Qabc");
        peoples[1].age = 20;
        peoples[1].name = new String("Adjkj");
        peoples[2].age = 5;
        peoples[2].name = new String("Bdskfjc");
        peoples[4].age = 5;
        peoples[4].name = new String("Adskfjc");
        List<People> peopleList = new ArrayList<>(1);
        for (int i = 0; i < peoples.length; i++) {
            peopleList.add(peoples[i]);
        }
        Collections.sort(peopleList);

        for (People p : peopleList) {
            Log.d("LA", String.valueOf(p.age) + " " + p.name);
        }
        Log.d("TEST", "b=" + biggest + " s=" + second);

        String a = "abc";
        char[] ac = a.toCharArray();
        int i = 0;
        char b;
        try {
            do {
                b = ac[i];
                i++;
            } while (true);
        } catch (Exception e) {

        }

        int len = a.lastIndexOf("");

        Pattern pattern = Pattern.compile("$");
        Matcher matcher = pattern.matcher("abc");
        boolean m = matcher.matches();
        matcher.find();
        len = matcher.end();


        String text =
                "sfdsdf This is the text to be searched " +
                        "for occurrences This is the text of the http:// pattern.";

        String patternString = "This is the";

        pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
        matcher = pattern.matcher(text);

        System.out.println("lookingAt = " + matcher.lookingAt());
        System.out.println("matches   = " + matcher.matches());

        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();
            Log.d("LA", text.substring(start, end));
        }

        try {
            InputStream is = getAssets().open("name.txt");
            InputStreamReader reader = new InputStreamReader(is);
            byte[] bn = new byte[100];
            int c;
            len = 0;
            while ((c = is.read()) != -1) {
                bn[len] = (byte) c;
                len++;
            }
            String sname = new String(bn, 0, len);
            String[] snameA = sname.split("\n");

            BufferedReader bufferedReader = new BufferedReader(reader);
            String line = "";
            int count = 0;

            is.reset();
            while ((line = bufferedReader.readLine()) != null) {
                snameA[count++] = line;
            }

            is.reset();

            baos = new ByteArrayOutputStream();

            int buflen = 8;
            byte[] buffer = new byte[buflen];
            int readlen = 0;
            while ((readlen = is.read(buffer, 0, buflen)) != -1) {
                baos.write(buffer, 0, readlen);
            }
            byte[] buffer2 = new byte[1024];
            buffer2 = baos.toByteArray();
            String sname2 = new String(buffer2, 0, baos.size());
            String[] snameB = sname.split("\n");

            is.close();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Here, thisActivity is the current activity
                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {

                    // Should we show an explanation?
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                        // Show an explanation to the user *asynchronously* -- don't block
                        // this thread waiting for the user's response! After the user
                        // sees the explanation, try again to request the permission.


                        AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
                        builder2.setMessage("need to request permission for write external storage")
                                .setTitle("Permission Request")
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Log.d("LA", "OK");

                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Log.d("LA", "Cancel");

                                    }
                                });
                        AlertDialog alertDialog2 = builder2.show();


                    } else {

                        // No explanation needed, we can request the permission.

                        ActivityCompat.requestPermissions(this,
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                MY_PERMISSIONS_REQUEST_WRITE_EXT);

                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        Intent fakeIntent = new Intent(Intent.ACTION_VIEW);
            Uri fake_uri = Uri.parse("fake_uri");

            fakeIntent.setDataAndType(fake_uri, "fake_type" );

        PackageManager pm = this.getPackageManager();
        ActivityManager am;
        String context = Context.ACTIVITY_SERVICE;
        am = (ActivityManager)getSystemService(context);

        ComponentName cm = fakeIntent.resolveActivity(pm);
        ActivityInfo activityInfo = fakeIntent.resolveActivityInfo(pm, fakeIntent.getFlags());
        if ( (cm != null) && (activityInfo.exported) ) {
            try {
                startActivity(fakeIntent);
            } catch (ActivityNotFoundException e) {
                Log.d("LA", "Not found");

            }
        }

        Cursor c = getContentResolver().query(ScoreProvider.CONTENT_URI_ADD_ITEM,null,null,null,null);
        if (c != null && c.moveToFirst()) {
            do {
                String num1 = c.getString(c.getColumnIndex(TestRecordDao.KEY_NUM1));


                Log.d("LA", "num1="+num1);
            } while ((c.moveToNext()));
        }

        String[] projection = {TestRecordDao.KEY_NUM1, TestRecordDao.KEY_NUM2, TestRecordDao.KEY_RES1, TestRecordDao.KEY_RES2};
        String selection = TestRecordDao.KEY_OP + "=?" + " AND " + TestRecordDao.KEY_NUM1 + ">?";
        String[] selectionArgs = {"+", "2000"};
        String sortOrder = TestRecordDao.KEY_NUM1+","+TestRecordDao.KEY_NUM2;

         c = getContentResolver().query(ScoreProvider.CONTENT_URI_ADD,projection,selection,selectionArgs,sortOrder);
        if (c != null && c.moveToFirst()) {
            do {
                String num1 = c.getString(c.getColumnIndex(TestRecordDao.KEY_NUM1));
                String num2 = c.getString(c.getColumnIndex(TestRecordDao.KEY_NUM2));






                Log.d("LA", String.format("num1=%s num2=%s",num1,num2));
            } while ((c.moveToNext()));
        }

        FragmentManager fragmentManager = getSupportFragmentManager();

        ScoreFragment fragment = (ScoreFragment)fragmentManager.findFragmentById(R.id.score_title);

        if (fragment != null) {
            Log.d("LA", "Found existing ScoreFragment Name=" + fragment.getName());

        } else {
            FragmentTransaction ft = fragmentManager.beginTransaction();

            ScoreFragment scoreFragment = new ScoreFragment();
            scoreFragment.setRetainInstance(true);
            ft.add(R.id.score_title, scoreFragment);
            // ft.addToBackStack(ScoreFragment.TAG);
            ft.commit();
        }


        Log.d("LA", "END");

    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.math, menu);
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_WRITE_EXT: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
;

                    String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
                    path += File.separator + "testfile.txt";
                    File f = new File(path);
                    if (f.exists()) {
                        f.delete();
                    }
                    try {
                        f.createNewFile();

                        FileOutputStream fos = new FileOutputStream(f);


                        baos.writeTo(fos);
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                } else {

                    Toast.makeText(this, "PERMISSION DENIED", Toast.LENGTH_LONG);

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private class People implements Comparable<People> {
        public String name;
        public Integer age;


        @Override
        public int compareTo(@NonNull People another) {
            int order = 0;
            if (age < another.age) {
                order = -1;
            } else if (age == another.age) {
                if (name.compareTo(another.name) < 0) {
                    order = 1;
                } else if (name.compareTo(another.name) == 0) {
                    order = 0;
                } else {
                    order = -1;
                }
            } else {
                order = 1;
            }
            return order;
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void initUI() {
        final LinearLayout loginLayout = (LinearLayout) findViewById(R.id.login_page);
        final EditText nameEdit = (EditText) findViewById(R.id.NameValue);
        final EditText pwdEdit = (EditText) findViewById(R.id.PwdValue);
        login = (Button) findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginCredential loginCredential = new LoginCredential();
                loginCredential.name = nameEdit.getText().toString();
                loginCredential.pwd = pwdEdit.getText().toString();
                presenter.loginCheck(loginCredential);

            }
        });
        loginLayout.setSystemUiVisibility(loginLayout.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    }

    @Override
    public void showStatus(String status) {

    }

    @Override
    public void loginStatus(Boolean staus) {
        Intent i = new Intent(this, MathActivity.class);
        startActivity(i);
    }

    public interface LoginStatus {
        public static final String FAIL_MANY_ATTEMPT = "FAIL_MANY_ATTEMPT";
    }


}
