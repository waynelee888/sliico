package com.slinetwork.mathtutor.networks;

import android.content.Context;

import org.apache.http.conn.ClientConnectionManager;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpClientFactory {
    static Context context;
    private HttpClientFactory() {
    }

    public enum HttpClient {
        JAVA_NET_HTTP_CLIENT,
        APACHE_DEFAULT_HTTP_CLIENT,
        LOOPJ_ASYNC_HTTP_CLIENT,
        OK_HTTP_CLIENT,
        VOLLEY_HTTP_CLIENT,

    };

    public static HttpManagerBase getHttpManager(Context context, HttpClient httpClient, Object... params) {
        HttpClientFactory.context = context;
        HttpManagerBase httpManager;
        switch (httpClient) {
            case APACHE_DEFAULT_HTTP_CLIENT:
                int len = params.length;
                if (len == 0) {
                    httpManager = new HttpManagerApacheClient(context);
                } else if (len == 2) {
                    httpManager = new HttpManagerApacheClient(context, (ClientConnectionManager) (params[0]), (org.apache.http.params.HttpParams) (params[1]));

                } else if (len == 1) {
                    httpManager = new HttpManagerApacheClient(context, (org.apache.http.params.HttpParams) (params[0]));
                } else {
                    httpManager = null;
                }
                break;
            case JAVA_NET_HTTP_CLIENT:
                httpManager = new HttpManagerJavaNetClient(context);
                break;
            case LOOPJ_ASYNC_HTTP_CLIENT:
                httpManager = null;
                break;
            case OK_HTTP_CLIENT:
                httpManager = new HttpManagerOkHttpClient(context);
                break;

            case VOLLEY_HTTP_CLIENT:
                httpManager = null;
                break;

            default:
                httpManager = null;
        }
        return httpManager;
    }
}
