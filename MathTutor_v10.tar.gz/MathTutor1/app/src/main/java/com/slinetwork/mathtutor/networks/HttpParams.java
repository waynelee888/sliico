package com.slinetwork.mathtutor.networks;

import org.apache.http.NameValuePair;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wayne on 12/08/17.
 */

public abstract class HttpParams {
    URL url;
    List<NameValuePair> pairs;
    public HttpParams() {
        pairs = new ArrayList<>(0);
    }

    abstract public void setUrl(URL url);
    abstract public List<NameValuePair> getParams();

}
