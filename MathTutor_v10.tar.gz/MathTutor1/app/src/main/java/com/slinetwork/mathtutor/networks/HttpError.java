package com.slinetwork.mathtutor.networks;

/**
 * Created by wayne on 12/08/17.
 */

public class HttpError {
    ErrorType errorType;
    public enum ErrorType {
        ERROR_TYPE_NONE,
        ERROR_TYPE_BAD_CONN
    };
    public void setError (ErrorType error) {
        errorType = error;
    }
    public ErrorType getError () {
        return errorType;
    }
}
