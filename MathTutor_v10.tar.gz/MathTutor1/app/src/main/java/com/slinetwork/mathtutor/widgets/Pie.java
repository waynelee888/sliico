package com.slinetwork.mathtutor.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.slinetwork.mathtutor.R;

/**
 * Created by wayne on 20/08/17.
 */

public class Pie extends View {
    int weight;
    int gravity;
    public Pie(Context context) {
        super(context);
    }

    public Pie(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CustomPie);
        gravity = a.getInt(R.styleable.CustomPie_android_layout_gravity, gravity);
        weight = a.getInt(R.styleable.CustomPie_pie_weight, weight);
        a.recycle();

    }

    public Pie(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

}
