package com.slinetwork.mathtutor.providers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.slinetwork.mathtutor.activities.MathActivity;
import com.slinetwork.mathtutor.dao.TestRecordDao;

/**
 * Created by wayne on 17/08/17.
 */

public class ScoreProvider extends ContentProvider {
    static final String PROVIDER_NAME = "com.slinetwork.mathtutor.providers.ScoreProvider";
    static final String URL = "content://" + PROVIDER_NAME;
    public static final Uri CONTENT_URI = Uri.parse(URL);
    public static final Uri CONTENT_URI_ADD = Uri.withAppendedPath(CONTENT_URI, "addition");
    public static final Uri CONTENT_URI_ADD_ITEM = Uri.withAppendedPath(CONTENT_URI, "addition/1");
    public static final Uri CONTENT_URI_SUB = Uri.withAppendedPath(CONTENT_URI, "subtraction");
    public static final Uri CONTENT_URI_DIV = Uri.withAppendedPath(CONTENT_URI, "division");
    public static final Uri CONTENT_URI_MUL = Uri.withAppendedPath(CONTENT_URI, "multiply");

    public static final int ADDITION = 1;
    public static final int ADDITION_ID = 2;
    public static final int SUBTRACTION = 3;
    public static final int SUBTRACTION_ID = 4;
    public static final int DIVISION = 5;
    public static final int DIVISION_ID = 6;
    public static final int MULTIPLY = 7;
    public static final int MULTIPLY_ID = 8;

    private static final UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);

    static
    {
        matcher.addURI(PROVIDER_NAME, "addition", ADDITION);
        matcher.addURI(PROVIDER_NAME, "addition/#", ADDITION_ID);
        matcher.addURI(PROVIDER_NAME, "subtraction", SUBTRACTION);
        matcher.addURI(PROVIDER_NAME, "subtraction/#", SUBTRACTION_ID);
        matcher.addURI(PROVIDER_NAME, "division", DIVISION);
        matcher.addURI(PROVIDER_NAME, "division/#", DIVISION_ID);
        matcher.addURI(PROVIDER_NAME, "multiply", MULTIPLY);
        matcher.addURI(PROVIDER_NAME, "multiply/#", MULTIPLY_ID);
    }


    @Override
    public boolean onCreate() {
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        TestRecordDao testRecordDao;
        testRecordDao = new TestRecordDao(this.getContext());
        testRecordDao.databaseAccessible();
        Cursor c = null;
        int m = matcher.match(uri)  ;
        switch (m) {
            case ADDITION:
                // c = testRecordDao.getTestRecords(MathActivity.MathOperation.ADDITION);
                c = testRecordDao.getTestRecords(projection, selection, selectionArgs, sortOrder);
                break;
            case ADDITION_ID:
                c = testRecordDao.getTestRecords(MathActivity.MathOperation.ADDITION);
                break;
            case SUBTRACTION:
                break;
            case SUBTRACTION_ID:
                break;
            case DIVISION:
                break;
            case DIVISION_ID:
                break;
            case MULTIPLY:
                break;
            case MULTIPLY_ID:
                break;
            default:
                return null;
        }
        return c;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        String scoreType = null;
        int m = matcher.match(uri)  ;
        switch (m) {
            case ADDITION :
                scoreType = "vnd.android.cursor.dir/addition";
                break;
            case ADDITION_ID :
                scoreType = "vnd.android.cursor.item/addition";
                break;
            case SUBTRACTION :
                scoreType = "vnd.android.cursor.dir/subtraction";
                break;
            case SUBTRACTION_ID :
                scoreType = "vnd.android.cursor.item/subtraction";
                break;
            case DIVISION :
                scoreType = "vnd.android.cursor.dir/division";
                break;
            case DIVISION_ID :
                scoreType = "vnd.android.cursor.item/division";
                break;
            case MULTIPLY :
                scoreType = "vnd.android.cursor.dir/multiply";
                break;
            case MULTIPLY_ID :
                scoreType = "vnd.android.cursor.item/multiply";
                break;
            default:
                return null;
        }
        return scoreType;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
