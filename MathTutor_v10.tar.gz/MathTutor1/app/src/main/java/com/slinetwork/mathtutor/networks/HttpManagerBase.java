package com.slinetwork.mathtutor.networks;

import android.os.Environment;

import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by wayne on 12/08/17.
 */

public abstract class HttpManagerBase {
    HttpRequest httpRequest;
    ResponseListener responseListener;
    HttpError httpError;
    HttpStatus httpStatus;


    public void setHttpGetMethod(HttpGetParam httpParam) {

    httpRequest = new HttpRequest();

    HttpHeader httpHeader = new HttpHeader();
        httpRequest.setHttpHeader(httpHeader);

    HttpMethods httpMethods = new HttpGetMethod();
        httpRequest.setHttpMethods(httpMethods);

        httpRequest.setHttpParams(httpParam);
    }
    public void setHttpPostMethod(HttpPostParam httpParam) {
        httpRequest = new HttpRequest();

        HttpHeader httpHeader = new HttpHeader();
        httpRequest.setHttpHeader(httpHeader);

        HttpMethods httpMethods = new HttpPostMethod();
        httpRequest.setHttpMethods(httpMethods);

        httpRequest.setHttpParams(httpParam);
    }
    public void setResponseListener(ResponseListener responseListener) {
        this.responseListener = responseListener;
    }

    abstract public HttpResponse httpExecute();

    public interface ResponseListener {
        void onHttpError(HttpError httpError);
        void onHttpSuccess(HttpResponse httpResponse);
        void onHttpStatus(HttpStatus httpStatus);
    }

}
