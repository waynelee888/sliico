package com.slinetwork.mathtutor.internals.managers;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by wayne on 08/08/17.
 */

public class ThreadManager {
    ThreadPoolExecutor threadPoolExecutor;
    int cores=0;
    int max=0;
    int time =0;
    TimeUnit tu;
    private BlockingQueue<Runnable> mWorkQueue;

    public ThreadManager() {
        cores = Runtime.getRuntime().availableProcessors();
        max = cores;
        time = 1;
        tu = TimeUnit.SECONDS;
        mWorkQueue = new LinkedBlockingDeque<>();


        threadPoolExecutor = new ThreadPoolExecutor(cores, max, time, tu, mWorkQueue);
    }
    public void addWork (Runnable runnable){
        threadPoolExecutor.execute(runnable);

    }
    public void deleteWork (Runnable runnable){
        mWorkQueue.remove(runnable);

    }
}
