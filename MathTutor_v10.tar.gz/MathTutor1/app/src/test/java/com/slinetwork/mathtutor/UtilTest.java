package com.slinetwork.mathtutor;

/**
 * Created by wayne on 08/08/17.
 */


import android.test.mock.MockContext;
import android.view.accessibility.AccessibilityManager;
import static org.hamcrest.MatcherAssert.assertThat;

import static org.hamcrest.CoreMatchers.*;

import static org.mockito.Mockito.*;

import static org.junit.Assert.*;

        import org.junit.After;
        import org.junit.Before;
        import org.junit.Test;


import com.slinetwork.mathtutor.utils.Util;

public class UtilTest {

    @Test
    public void testGetInstance() {
        Util util = Util.getInstance();
        assertNotNull(util);
    }

}