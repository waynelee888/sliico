package com.sliico.www.sliicoprojects.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;
import android.view.View;

import com.sliico.www.sliicoprojects.R;
import com.sliico.www.sliicoprojects.interfaces.OnCircleSelectionListener;

/**
 * Created by Wayne on 1/21/2016.
 */
public class CircleView extends View implements View.OnClickListener{

    private Paint mCirclePaint;
    private float mPointerX;
    private float mPointerY;
    private float mPointerRadius = 12.0f;
    private int mTextColor;
    private float mTextHeight = 0.0f;
    Canvas canvas;
    OnCircleSelectionListener listener;

    /**
     * Construct a PointerView object
     *
     * @param context
     */
    public CircleView(Context context) {
        super(context);
        mPointerX = 15;
        mPointerY = 15;
        mTextColor = getResources().getColor(R.color.blue);
        mCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mCirclePaint.setColor(mTextColor);
        if (mTextHeight == 0) {
            mTextHeight = mCirclePaint.getTextSize();
        } else {
            mCirclePaint.setTextSize(mTextHeight);
        }

    }

    @Override
    protected void onDraw(Canvas canvas) {
        this.canvas = canvas;
        canvas.drawCircle(mPointerX, mPointerY, mPointerRadius, mCirclePaint);
    }

    public void setCircleValue(Boolean onOff) {
        if (onOff == true) {
            mTextColor = getResources().getColor(R.color.pale_red);
            mCirclePaint.setColor(mTextColor);
            mPointerRadius = 12;

        } else {
            mTextColor = getResources().getColor(R.color.black);
            mCirclePaint.setColor(mTextColor);
            mPointerRadius = 6f;
        }
        invalidate();
    }

    public void reduceCircleRadius(float offset) {

        float tmp = mPointerRadius = 12;
        tmp = tmp - mPointerRadius / 2 * offset;
        if (tmp < 6) {
            tmp = 6f;
        }

        mPointerRadius = tmp;
        this.invalidate();

    }
    public void enlargeCircleRadius(float offset) {
        float tmp = mPointerRadius = 6f;
        tmp = tmp + mPointerRadius * offset;
        if (tmp > 12) {
            tmp = 12;
        }
        mPointerRadius = tmp;
        this.invalidate();

    }

    @Override
    public void onClick(View v) {
        if (v == this) {
            Log.d("CV", "circle clicked=" + this.toString());
            listener.onSelected(this);
        } else {
            Log.d("CV", "item clicked=" + v.toString());
        }
    }
    public void setSelectionListener(OnCircleSelectionListener listener) {
        this.listener = listener;

    }
}
