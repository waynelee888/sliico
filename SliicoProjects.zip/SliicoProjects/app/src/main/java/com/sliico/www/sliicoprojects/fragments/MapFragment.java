package com.sliico.www.sliicoprojects.fragments;

/**
 * Created by Wayne on 1/15/2016.
 */
public class MapFragment extends BaseFragment {
}
