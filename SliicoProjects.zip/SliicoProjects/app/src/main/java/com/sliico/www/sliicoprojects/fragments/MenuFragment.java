package com.sliico.www.sliicoprojects.fragments;

/**
 * Created by Wayne on 1/14/2016.
 */
public class MenuFragment extends BaseFragment {
}
