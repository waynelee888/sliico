package com.sliico.www.sliicoprojects.interfaces;

import android.app.Fragment;
import android.support.v4.view.ViewPager;

import com.sliico.www.sliicoprojects.adapter.ViewPagerFragmentAdapter;

import java.util.ArrayList;

/**
 * Created by Wayne on 12/26/2015.
 */
public interface OnProjectChangeListener {
    void onProjectAdd(int icon);
    void onProjectRemove(int icon);
}
