package com.sliico.www.sliicoprojects.adapter;


import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.support.v13.app.FragmentPagerAdapter;
import android.support.v13.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;

import com.sliico.www.sliicoprojects.fragments.PageIndicatorFragment;
import com.sliico.www.sliicoprojects.fragments.ViewPagerFragment;
import com.sliico.www.sliicoprojects.interfaces.OnProjectClickListener;

import java.util.ArrayList;

/**
 * Created by Wayne on 1/15/2016.
 */
public class ViewPagerFragmentAdapter extends FragmentStatePagerAdapter {
    private static final String TAG = ViewPagerFragment.class.getSimpleName();
    ArrayList<Fragment> fragments;

    public ViewPagerFragmentAdapter(Context context, FragmentManager fm, ArrayList<Fragment> fragments) {
        super(fm);
        this.fragments = fragments;
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

}
