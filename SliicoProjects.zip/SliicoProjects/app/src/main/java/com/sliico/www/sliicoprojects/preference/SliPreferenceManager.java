package com.sliico.www.sliicoprojects.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.sliico.www.sliicoprojects.Preferences;
import com.sliico.www.sliicoprojects.R;

/**
 * Created by Wayne on 1/14/2016.
 */
public class SliPreferenceManager {
    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    private SliPreferenceManager(Context context) {
        this.context = context;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = sharedPreferences.edit();
    }
    private SliPreferenceManager(Context context, String prefName) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(prefName, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public static SliPreferenceManager getInstance(Context context) {
        return new SliPreferenceManager(context);
    }

    public static SliPreferenceManager getInstance(Context context, String prefName) {
        return new SliPreferenceManager(context, prefName);
    }

    public String getString(String key) {
        return sharedPreferences.getString(key, null);
    }
    public void saveString(String key, String name) {
        editor.putString(key, name);
        editor.commit();
    }
    public int getInt(String key) {
        return sharedPreferences.getInt(key, 0);
    }
    public void saveInt(String key, int value) {
        editor.putInt(key, value);
        editor.commit();
    }
    public Boolean getBoolean(String key) {
        return sharedPreferences.getBoolean(key, false);
    }
    public void saveBoolean(String key, Boolean value) {
        editor.putBoolean(key, value);
        editor.commit();
    }

    public interface PreferenceKeys {
        String checkBoxKey = "checkBoxKey";
        String editTextKey = "editTextKey";
        String projectList = "projectList";
        String uiCat = "uiCat";
        String frameKey = "frameKey";
    }
    public interface PreferenceKeyCopy {
        String checkBoxKeyCopy = "checkBoxKeyCopy";
        String editTextKeyCopy = "editTextKeyCopy";
        String projectListCopy = "projectListCopy";
        String uiCatCopy = "uiCatCopy";
        String frameKeyCopy = "frameKeyCopy";
    }
    public interface PreferenceNames {
        String bankPref = "BANK";
        String tradePref = "TRADE";
        String termPref = "TERM";
    }

}
