package com.sliico.www.sliicoprojects.interfaces;

/**
 * Created by Wayne on 1/19/2016.
 */
public interface OnListItemSelectedListener {
    void onSelected(int position);
}
