package com.sliico.www.sliicoprojects.controllers;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;

/**
 * Created by Wayne on 12/26/2015.
 */
public class MainController extends Activity {
    /*
    public DrawerLayout getDrawerLayout() {
        return drawerMenu.getDrawerLAyout();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        populateDrawerMenu();
        setActionBarCustomView(getResources().getString(R.string.globalStaticContentQuickLinksHome), false);

    }
    */
}
