package com.sliico.www.sliicoprojects.fragments;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.sliico.www.sliicoprojects.NavItem;
import com.sliico.www.sliicoprojects.R;
import com.sliico.www.sliicoprojects.adapter.ViewPagerFragmentAdapter;
import com.sliico.www.sliicoprojects.interfaces.OnCircleSelectionListener;
import com.sliico.www.sliicoprojects.interfaces.OnListItemSelectedListener;
import com.sliico.www.sliicoprojects.interfaces.OnProjectChangeListener;
import com.sliico.www.sliicoprojects.widgets.CircleView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;


/**
 * Created by Wayne on 1/14/2016.
 */
public class ProjectViewPagerFragment extends ViewPagerFragment
        implements PictureFragment.AppLaunchIcon,
        OnProjectChangeListener,
        OnListItemSelectedListener {

    private static final String TAG = ProjectViewPagerFragment.class.getSimpleName();
    String msg;
    TextView tv;
    ViewPager viewPager;
    int curPos;
    ArrayList<Integer> iconList;
    ArrayList<Integer> iconListRestore;
    Boolean restoredVPF;

    ViewPagerFragmentAdapter viewPagerFragmentAdapter;
    FragmentManager fm;
    ArrayList<Fragment> fragments;
    Context context;
    ViewPager.OnPageChangeListener drawerListlistener;
    ArrayList<ViewPager.OnPageChangeListener> listeners;

    PageIndicatorFragment pageIndicatorFragment;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("PPF", "onCreate" + this.toString());

        restoredVPF = false;
        fm = getFragmentManager();
        fragments = new ArrayList<>(0);
        listeners = new ArrayList<>(0);

        if (savedInstanceState != null) {
            curPos = savedInstanceState.getInt("CURPOS");
            iconListRestore = savedInstanceState.getIntegerArrayList("ICONS");
        }
        iconList = new ArrayList<>(0);

        Bundle b = getArguments();
        if (b != null) {
            msg = b.getString("MSG", "no found");
        }


    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("PPF", "onResume" + this.toString());

//        viewPager.setCurrentItem(curPos, true);
//        viewPager.invalidate();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("PPF", "onPause=" + this.toString());
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("PPF", "onStop" + this.toString());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d("PPF", "onDestroyView" + this.toString());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("PPF", "onDestroy" + this.toString());
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putInt("CURPOS", curPos);
        outState.putIntegerArrayList("ICONS", iconList);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onViewStateRestored(Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        Log.d("PPF", "onCreateView" + this.toString());

        View view = inflater.inflate(R.layout.project_view_pager, container, false);
        if (msg != null) {
            tv = (TextView) view.findViewById(R.id.hello);
            tv.setText(msg);
        }
        initUI(view);
        return view;
    }

    private void initUI(View view) {
//        listener.initProjectViewPagerFragments(fragments);
        viewPager = (ViewPager) view.findViewById(R.id.project_viewpager);
        FrameLayout pageIndicatorFragmentContainer;
        pageIndicatorFragmentContainer = (FrameLayout) view.findViewById(R.id.page_indicator_fragment_container);

//        pageIndicatorFragment = (PageIndicatorFragment)fm.findFragmentById(R.id.page_indicator_fragment);

        pageIndicatorFragment = (PageIndicatorFragment) Fragment.instantiate(context, PageIndicatorFragment.class.getName());
        pageIndicatorFragment.initPageIndicator(fragments.size());
        pageIndicatorFragment.setListItemSelectedListener(this);
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.page_indicator_fragment_container, pageIndicatorFragment);
        ft.addToBackStack(null);
        ft.commit();

        listeners.add(pageIndicatorFragment);
        listeners.add(drawerListlistener);

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                Log.d(TAG, "onPageScrolled: pos=" + position + " offset=" + positionOffset + " offpixel=" + positionOffsetPixels);
                pageIndicatorFragment.onPageScrolled(position, positionOffset, positionOffsetPixels);
            }

            @Override
            public void onPageSelected(int position) {

                curPos = position;
                for (int i = 0; i < listeners.size(); i++) {
                    listeners.get(i).onPageSelected(position);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                pageIndicatorFragment.onPageScrollStateChanged(state);

            }
        });

        viewPagerFragmentAdapter = new ViewPagerFragmentAdapter(context, fm, fragments);
        viewPager.setAdapter(viewPagerFragmentAdapter);
        viewPager.setOffscreenPageLimit(1);


    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
//        listener = (ProjectViewPagerActions)activity;
        context = activity.getApplicationContext();
        drawerListlistener = (ViewPager.OnPageChangeListener) activity;
    }

    @Override
    public void onProjectAdd(int icon) {
        iconList.add(icon);
        PictureFragment f = createPictureFragment(icon);
        fragments.add(f);
        viewPagerFragmentAdapter.notifyDataSetChanged();
        pageIndicatorFragment.addPage();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (savedInstanceState != null) {
            restoredVPF = true;
        }

    }

    @Override
    public void onStart() {
        super.onStart();
        if (restoredVPF == true) {
            for (Integer icon : iconListRestore) {
                onProjectAdd(icon.intValue());
            }
            viewPager.setCurrentItem(curPos, true);
        }
    }

    @Override
    public void onProjectRemove(int icon) {
        iconList.remove(Integer.valueOf(icon));
        Fragment fragment = null;
        int index = 0;
        Boolean found = false;

        for (Fragment f : fragments) {
            if (((PictureFragment) f).getIcon() == icon) {
                fragment = f;
                found = true;
                break;
            }
            index++;
        }
        if (fragment != null) {
            fragments.remove(fragment);
        }

        /*
        Iterator<Fragment> iterator = fragments.iterator();
        while (iterator.hasNext()) {
            fragment = iterator.next();
            if (((PictureFragment)f).getIcon() == icon)  {
                iterator.remove();
                found = true;
                break;
            }
            index++;
        }
        */
        if (found != null) {
            viewPagerFragmentAdapter.notifyDataSetChanged();
            pageIndicatorFragment.removePage(index);
        }
    }

    private PictureFragment createPictureFragment(int icon) {
        PictureFragment fragment = new PictureFragment();
        Bundle b = new Bundle();
        b.putInt(name, icon);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    public void onSelected(int position) {
        curPos = position;
        viewPager.setCurrentItem(position, true);
    }

}
