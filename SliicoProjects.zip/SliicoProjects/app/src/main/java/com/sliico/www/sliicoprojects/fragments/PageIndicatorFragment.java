package com.sliico.www.sliicoprojects.fragments;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.sliico.www.sliicoprojects.R;
import com.sliico.www.sliicoprojects.interfaces.OnCircleSelectionListener;
import com.sliico.www.sliicoprojects.interfaces.OnListItemSelectedListener;
import com.sliico.www.sliicoprojects.widgets.*;

/**
 * Created by Wayne on 1/16/2016.
 */
public class PageIndicatorFragment extends BaseFragment implements ViewPager.OnPageChangeListener, OnCircleSelectionListener {
    private static final String TAG = PageIndicatorFragment.class.getSimpleName();

    int size;
    int curPos;
    LinearLayout pageIndicator;
    OnListItemSelectedListener listItemSelectedListener;

    Context context;

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        context = activity.getApplicationContext();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.page_indicator, container, false);
        initUI(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private void initUI(View view) {
        pageIndicator = (LinearLayout) view.findViewById(R.id.page_indicator);
    }

    public void updatePageIndicator(int position) {

        pageIndicator.removeViewAt(curPos);
        pageIndicator.addView(createCircle(R.drawable.page_off));

        pageIndicator.removeViewAt(position);
        pageIndicator.addView(createCircle(R.drawable.page_on), position);

        curPos = position;
    }

    public void initPageIndicator(int size) {
        if (size == 0) return;
        this.size = size;
        curPos = 0;
        pageIndicator.addView(createCircle(R.drawable.page_on));
        for (int i = 1; i < size; i++) {
            pageIndicator.addView(createCircle(R.drawable.page_off));
        }
    }

    public void addPage() {
        if (size == 0) {
            pageIndicator.addView(createCircle(R.drawable.page_on));
        } else {
            pageIndicator.addView(createCircle(R.drawable.page_off));
        }
        size++;
    }

    public void removePage(int position) {
        if (size == 0) {
            return;
        } else {
            pageIndicator.removeViewAt(position);
        }
        size--;
    }

    private ImageView createImage(int id) {
        Drawable drawable = getResources().getDrawable(id);
        ImageView imageView = new ImageView(context);
        imageView.setImageDrawable(drawable);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(30, 30);
        ll.gravity = Gravity.CENTER;

        imageView.setLayoutParams(ll);
        int pixel = (int) context.getResources().getDimension(
                R.dimen.page_padding);
        ;
        imageView.setPadding(pixel, 0, pixel, 0);
        return imageView;
    }

    private CircleView createCircle(int id) {
        CircleView circleView = new CircleView(context);
        circleView.setOnClickListener(circleView);
        circleView.setSelectionListener(this);
        if (id == R.drawable.page_on) {
            circleView.setCircleValue(true);
        } else {
            circleView.setCircleValue(false);
        }
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(60, 60);
        ll.gravity = Gravity.CENTER;

        circleView.setLayoutParams(ll);
//        int pixel = (int) context.getResources().getDimension(
//                R.dimen.page_padding);;
//        circleView.setPadding(pixel, 0, pixel, 0);
        return circleView;

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        Log.d(TAG, "onPageScrolled: pos=" + position + " offset=" + positionOffset + " offpixel=" + positionOffsetPixels);

        // work around an Android bug: when showing last page, position can be the page before it
        if ((position == size - 2) && (positionOffset > 0.998)) {
            position = position + 1;
            positionOffset = 0;
        }
        // current position always reduce circle from 10 - 10 * offset
        // if offset going toward from 1 to 0, then it is enlarging the circle
        CircleView circleViewCurrent = (CircleView) pageIndicator.getChildAt(position);
        if (circleViewCurrent != null) {
            circleViewCurrent.reduceCircleRadius(positionOffset);
        }
        // next position always enlarge circle from 5
        // if offset going toward from 0 to 1, then it is reducing the circle
        CircleView circleViewNext = null;
        if (position < size - 1) {
            circleViewNext = (CircleView) pageIndicator.getChildAt(position + 1);
            if (circleViewNext != null) {
                circleViewNext.enlargeCircleRadius(positionOffset);
            }
        }
    }

    @Override
    public void onPageSelected(int position) {
        Log.d(TAG, "onPageSelected");
        updatePageIndicator(position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        Log.d(TAG, "onPageScrollStateChanged");
        if (state == ViewPager.SCROLL_STATE_DRAGGING) {
            Log.d(TAG, "state=" + "SCROLL_STATE_DRAGGING");
        } else if (state == ViewPager.SCROLL_STATE_IDLE) {
            Log.d(TAG, "state=" + "SCROLL_STATE_IDLE");
            settleCircles();
        } else {
            Log.d(TAG, "state=" + "SCROLL_STATE_SETT");
        }
    }

    private void settleCircles() {
        for (int i = 0; i < size; i++) {
            CircleView circleView = (CircleView) pageIndicator.getChildAt(i);
            if (i == curPos) {
                circleView.setCircleValue(true);
            } else {
                circleView.setCircleValue(false);
            }
        }
    }

    @Override
    public void onSelected(CircleView circleView) {
        Boolean found = false;
        int i = 0;
        for (i = 0; i < size; i++) {
            if (pageIndicator.getChildAt(i) == circleView) {
                found = true;
                break;
            }
        }
        if (found == true) {
            updatePageIndicator(i);
            listItemSelectedListener.onSelected(i);
        }
    }

    void setListItemSelectedListener(OnListItemSelectedListener listener) {
        listItemSelectedListener = listener;
    }

}
