package com.sliico.www.sliicoprojects;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.util.Log;

import com.sliico.www.sliicoprojects.preference.SliPreferenceManager;

/**
 * Created by Wayne on 1/13/2016.
 */
public class Preferences extends PreferenceActivity
        implements SliPreferenceManager.PreferenceKeys,
                    SliPreferenceManager.PreferenceKeyCopy,
                    SliPreferenceManager.PreferenceNames {
    private static final String TAG = Preferences.class.getSimpleName();
    SliPreferenceManager sliPreferenceManagerBank;
    SliPreferenceManager sliPreferenceManagerTrade;
    SliPreferenceManager sliPreferenceManagerTerm;
    SharedPreferences.OnSharedPreferenceChangeListener listener = new SharedPreferences.OnSharedPreferenceChangeListener() {
        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            switch (key) {
                case checkBoxKey:
                    Boolean checkBox = sharedPreferences.getBoolean(key, false);
                    sliPreferenceManagerBank.saveBoolean(checkBoxKeyCopy, checkBox);
                    Boolean checkBoxCopy = sliPreferenceManagerBank.getBoolean(checkBoxKeyCopy);
                    break;
                case editTextKey:
                    String editText = sharedPreferences.getString(key, "weight");
                    sliPreferenceManagerTrade.saveString(editTextKeyCopy, editText);
                    String editTextCopy = sliPreferenceManagerTrade.getString(editTextKeyCopy);
                    break;
                case projectList:
                    Integer i = Integer.parseInt(sharedPreferences.getString(key, String.valueOf(R.string.project_id_default)));
                    sliPreferenceManagerTerm.saveInt(projectListCopy, i);
                    Integer iCopy = sliPreferenceManagerTerm.getInt(projectListCopy);
                    break;
                case uiCat:
                    Log.d(TAG, "user pressed UI Cat");
                case frameKey:
                    Boolean uiBox = sharedPreferences.getBoolean(key, false);
                    break;
                default:
                    break;
            }

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
        sliPreferenceManagerBank = SliPreferenceManager.getInstance(getApplicationContext(), bankPref);
        sliPreferenceManagerTrade = SliPreferenceManager.getInstance(getApplicationContext(), tradePref);
        sliPreferenceManagerTerm = SliPreferenceManager.getInstance(getApplicationContext(), termPref);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(listener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(listener);
    }
}
