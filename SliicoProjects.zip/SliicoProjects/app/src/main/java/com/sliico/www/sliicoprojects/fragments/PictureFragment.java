package com.sliico.www.sliicoprojects.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.sliico.www.sliicoprojects.R;
import com.sliico.www.sliicoprojects.interfaces.OnProjectClickListener;

import java.util.Locale;

/**
 * Created by Wayne on 1/15/2016.
 */
public class PictureFragment extends BaseFragment {
    private static final String TAG = PictureFragment.class.getSimpleName();
    private int icon;
    private Context context;
    OnProjectClickListener listener;


    public interface AppLaunchIcon {
        String name = "PICTURE_NAME";
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle b = getArguments();
        icon = b.getInt(AppLaunchIcon.name);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.app_launcher_picture, container, false);
        ImageView imageView = (ImageView)view.findViewById(R.id.app_launch_icon);
        imageView.setImageResource(icon);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClick(icon);
                Log.d(TAG, "picture clicked");
            }
        });
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        context = activity.getApplicationContext();
        listener = (OnProjectClickListener)activity;

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public int getIcon() {
        return icon;
    }


}
