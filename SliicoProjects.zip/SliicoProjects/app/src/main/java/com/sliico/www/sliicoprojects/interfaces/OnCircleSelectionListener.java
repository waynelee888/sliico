package com.sliico.www.sliicoprojects.interfaces;

import com.sliico.www.sliicoprojects.widgets.CircleView;

/**
 * Created by Wayne on 1/24/2016.
 */
public interface OnCircleSelectionListener {
    void onSelected(CircleView circleView);
}
