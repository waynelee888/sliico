package com.sliico.www.sliicoprojects;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.sliico.www.sliicoprojects.adapter.NavItemAdapter;
import com.sliico.www.sliicoprojects.fragments.PictureFragment;
import com.sliico.www.sliicoprojects.fragments.ProjectViewPagerFragment;
import com.sliico.www.sliicoprojects.interfaces.OnListItemSelectedListener;
import com.sliico.www.sliicoprojects.interfaces.OnProjectChangeListener;
import com.sliico.www.sliicoprojects.interfaces.OnProjectClickListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends Activity
        implements PictureFragment.AppLaunchIcon,
        OnProjectClickListener,
        ViewPager.OnPageChangeListener {
    private DrawerLayout dl;
    private ListView lv;
    private ActionBarDrawerToggle toggle;
    private CharSequence mDrawerTitle;
    private CharSequence mTitle;
    private String[] names;
    private TypedArray icons;
    private String[] name_icons;
    private String[] ni_pairs;
    private String[] name_icons_json;
    private String[] pname;
    private Fragment fragment;
    private LinearLayout ll;
    private ArrayList<NavItem> navItems;
    OnProjectChangeListener projectChangeListener;
    OnListItemSelectedListener listItemSelectedListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = (ListView) findViewById(R.id.list_slidermenu);
        dl = (DrawerLayout) findViewById(R.id.drawer_layout);
        ll = (LinearLayout) findViewById(R.id.target);

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ProjectViewPagerFragment f = new ProjectViewPagerFragment();
        ft.add(R.id.target, f);

        ProjectViewPagerFragment f2 = null;
        if (savedInstanceState == null) {
            f2 = new ProjectViewPagerFragment();
            Bundle b = new Bundle();
            b.putString("MSG", "Project Launcher");
            f2.setArguments(b);
            ft.replace(R.id.target, f2, "PPF");
            ft.remove(f);
            ft.commit();
        } else {
            f2 = (ProjectViewPagerFragment)fm.findFragmentByTag("PPF");
        }

        setProjectChangeListener(f2);
        setListItemSelectedListener(f2);

        navItems = new ArrayList<>(0);

/*
// method 1:
        names = getResources().getStringArray(R.array.projects);
        icons = getResources().obtainTypedArray(R.array.nav_drawer_icons);
        int i = 0;
        for (String name : names) {
            navItems.add(new NavItem(name, icons.getResourceId(i++, 0)));
        }
*/
        /*
// method 2:
        name_icons = getResources().getStringArray(R.array.project_name_icon);
        int i=0;
        names = new String[name_icons.length];
        for (String s : name_icons) {
            ni_pairs = s.split(",");
            names[i] = ni_pairs[0];
            int imageId = getResources().getIdentifier(ni_pairs[1].toLowerCase(Locale.getDefault()),
                    "drawable", this.getPackageName());
            navItems.add(new NavItem(names[i], imageId));
        }
        */


// method 3:
        name_icons_json = getResources().getStringArray(R.array.project_name_icon_json);
        int i = 0;
        names = new String[name_icons_json.length];
        pname = new String[name_icons_json.length];
        for (String s : name_icons_json) {
            try {
                JSONObject json = new JSONObject(s);
                names[i] = json.getString("name");
                String icon = json.getString("icon");
                pname[i] = json.optString("package");
                int imageId = getResources().getIdentifier(icon.toLowerCase(Locale.getDefault()),
                        "drawable", this.getPackageName());
                navItems.add(new NavItem(names[i], imageId, pname[i]));
                i++;
            } catch (JSONException jsonE) {
                Log.d("TEST", jsonE.toString());
            }
        }


//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.nav_list_item, names);
        NavItemAdapter adapter = new NavItemAdapter(this, R.layout.nav_list_item, navItems);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                NavItem navItem = (NavItem) parent.getItemAtPosition(position);
                Log.d("TEST", navItem.name);

                selectItem(position);
                listItemSelectedListener.onSelected(position);
            }
        });

        // enable ActionBar app icon to behave as action to toggle nav drawer
        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setHomeButtonEnabled(true);

        mTitle = getTitle();
        mDrawerTitle = "Navigations";

        toggle = new ActionBarDrawerToggle(this, dl, R.drawable.ic_drawer, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                //getActionBar().setTitle(mDrawerTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()

            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                //getActionBar().setTitle(mTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()

            }
        };
        dl.setDrawerListener(toggle);
//        if (savedInstanceState == null) {
//            selectItem(0);
//        }

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        toggle.syncState();

        if (savedInstanceState == null) {
            for (int i = 0; i < navItems.size(); i++) {
                projectChangeListener.onProjectAdd(navItems.get(i).getIcon());
            }
        }

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        toggle.onConfigurationChanged(newConfig);
    }

    private void setSelectItem(int position) {
        // highlight listview item but not launch item
        // unset listener, check item, set back lister
        AdapterView.OnItemClickListener listener = lv.getOnItemClickListener();
        lv.setOnItemClickListener(null);
        lv.setItemChecked(position, true);
        lv.setOnItemClickListener(listener);
        setTitle(names[position]);

    }

    private void selectItem(int position) {
        // update selected item and title, then close the drawer
        lv.setItemChecked(position, true);
        setTitle(names[position]);
        dl.closeDrawer(lv);
        /*
        //method 1:
        try {
            openApp(pname[position]);
        } catch (PackageManager.NameNotFoundException notfound) {
            Log.d("TEST", "name not found");
        }
        */

        //method 2:
        startApp(pname[position]);

    }

    void openApp(String pname) throws PackageManager.NameNotFoundException {
        if (pname != null && pname.length() != 0) {
            PackageManager pm = getPackageManager();
            Intent intent = pm.getLaunchIntentForPackage(pname);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            if (intent != null) {
                throw new PackageManager.NameNotFoundException();
            }
            startActivity(intent);
        }
    }

    private void launchComponent(String packageName, String name) {
        Intent launch_intent = new Intent(Intent.ACTION_MAIN);
        launch_intent.addCategory(Intent.CATEGORY_LAUNCHER);
        launch_intent.setComponent(new ComponentName(packageName, name));
        launch_intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(launch_intent);
    }

    void startApp(String pname) {
        PackageManager pm = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolveInfoList = pm.queryIntentActivities(intent, Intent.FLAG_ACTIVITY_NEW_TASK);
        for (ResolveInfo resolveInfo : resolveInfoList) {
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            if (activityInfo.packageName.equalsIgnoreCase(pname)) {
                launchComponent(pname, activityInfo.name);
            }
        }


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }

        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent prefIntent = new Intent(this, Preferences.class);
            startActivity(prefIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void setProjectChangeListener(OnProjectChangeListener listener) {
        projectChangeListener = listener;
    }

    private void setListItemSelectedListener(OnListItemSelectedListener listener) {
        listItemSelectedListener = listener;
    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onClick(int imageId) {

        Iterator<NavItem> itemIterator = navItems.iterator();
        while (itemIterator.hasNext()) {
            NavItem item = itemIterator.next();
            if (item.getIcon() == imageId) {
                String packageName = item.getPackageName();
                String appName = item.getName();
                startApp(packageName);
                break;
            }
        }

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        setSelectItem(position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
