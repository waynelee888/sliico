package com.sliico.www.sliicoprojects.interfaces;

/**
 * Created by Wayne on 1/17/2016.
 */
public interface OnProjectClickListener {
    void onClick(int icon);
}
