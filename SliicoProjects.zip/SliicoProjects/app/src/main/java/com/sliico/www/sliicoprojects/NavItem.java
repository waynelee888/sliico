package com.sliico.www.sliicoprojects;

/**
 * Created by Wayne on 12/27/2015.
 */
public class NavItem {
    String name;
    int icon;
    String packageName;
    public NavItem(String s, int icon, String packageName) {
        this.name = s;
        this.icon = icon;
        this.packageName = packageName;
    }
    public String getName() {
        return name;
    }
    public int getIcon() {
        return icon;
    }

    public String getPackageName() {
        return packageName;
    }
}
