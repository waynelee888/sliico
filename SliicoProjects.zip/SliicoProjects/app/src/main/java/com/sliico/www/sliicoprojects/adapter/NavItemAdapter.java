package com.sliico.www.sliicoprojects.adapter;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.sliico.www.sliicoprojects.MainActivity;
import com.sliico.www.sliicoprojects.NavItem;
import com.sliico.www.sliicoprojects.R;

import java.util.ArrayList;
import java.util.zip.Inflater;

/**
 * Created by Wayne on 12/27/2015.
 */
public class NavItemAdapter extends BaseAdapter {

    Context context;
    int     resourceId;
    ArrayList<NavItem> navItems;
    public NavItemAdapter(Context context, int resourceId, ArrayList<NavItem> navItems) {
        this.context = context;
        this.resourceId = resourceId;
        this.navItems = navItems;

    }
    @Override
    public int getCount() {
        return navItems.size();
    }

    @Override
    public Object getItem(int position) {
        return navItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resourceId, null);
//            LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//            convertView = layoutInflater.inflate(resourceId, parent);
        }
        TextView textView = (TextView)convertView.findViewById(R.id.nav_item_name);
        ImageView imageView = (ImageView)convertView.findViewById(R.id.nav_item_icon);
        NavItem navItem = navItems.get(position);
        textView.setText(navItem.getName());
        imageView.setImageResource(navItem.getIcon());

        return convertView;
    }
}
